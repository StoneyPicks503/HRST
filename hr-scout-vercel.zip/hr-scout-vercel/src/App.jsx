import { useState, useMemo, useCallback, useEffect } from "react";

const ANTHROPIC_API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY || "";

// ── Slate ────────────────────────────────────────────────────────────────
const GAMES = [
  { id:"astros-reds",       time:"4:10 PM",  away:"Astros",   home:"Reds",      park:"Great American Ball Park", awayP:"Spencer Arrighetti", awayH:"R", homeP:"Chase Burns",        homeH:"R", pf:1.18 },
  { id:"rockies-phillies",  time:"6:05 PM",  away:"Rockies",  home:"Phillies",  park:"Citizens Bank Park",       awayP:"Kyle Freeland",      awayH:"L", homeP:"Aaron Nola",         homeH:"R", pf:1.10 },
  { id:"athletics-orioles", time:"4:05 PM",  away:"Athletics",home:"Orioles",   park:"Camden Yards",             awayP:"Aaron Civale",       awayH:"R", homeP:"Shane Baz",          homeH:"R", pf:1.06 },
  { id:"angels-bluejays",   time:"3:07 PM",  away:"Angels",   home:"Blue Jays", park:"Rogers Centre",            awayP:"Jack Kochanowicz",   awayH:"R", homeP:"Trey Yesavage",      homeH:"R", pf:0.91 },
  { id:"nationals-marlins", time:"4:10 PM",  away:"Nationals",home:"Marlins",   park:"LoanDepot Park",           awayP:"Zack Littell",       awayH:"R", homeP:"Janson Junk",        homeH:"R", pf:0.99 },
  { id:"rays-redsox",       time:"4:10 PM",  away:"Rays",     home:"Red Sox",   park:"Fenway Park",              awayP:"Nick Martinez",      awayH:"R", homeP:"Payton Tolle",       homeH:"L", pf:1.05 },
  { id:"twins-guardians",   time:"6:10 PM",  away:"Twins",    home:"Guardians", park:"Progressive Field",        awayP:"Joe Ryan",           awayH:"R", homeP:"Tanner Bibee",       homeH:"R", pf:0.97 },
  { id:"mariners-whitesox", time:"7:10 PM",  away:"Mariners", home:"White Sox", park:"Guaranteed Rate Field",    awayP:"Luis Castillo",      awayH:"R", homeP:"Anthony Kay",        homeH:"L", pf:0.99 },
  { id:"tigers-royals",     time:"7:10 PM",  away:"Tigers",   home:"Royals",    park:"Kauffman Stadium",         awayP:"Burch Smith",        awayH:"R", homeP:"Michael Wacha",      homeH:"R", pf:0.95 },
  { id:"yankees-brewers",   time:"7:10 PM",  away:"Yankees",  home:"Brewers",   park:"American Family Field",    awayP:"Cam Schlittler",     awayH:"R", homeP:"Kyle Harrison",      homeH:"L", pf:1.08 },
  { id:"cubs-rangers",      time:"7:05 PM",  away:"Cubs",     home:"Rangers",   park:"Globe Life Field",         awayP:"Edward Cabrera",     awayH:"R", homeP:"Jack Leiter",        homeH:"R", pf:1.14 },
  { id:"mets-dbacks",       time:"7:15 PM",  away:"Mets",     home:"D-backs",   park:"Chase Field",              awayP:"Clay Holmes",        awayH:"R", homeP:"Merrill Kelly",      homeH:"R", pf:1.02 },
  { id:"cardinals-padres",  time:"7:15 PM",  away:"Cardinals",home:"Padres",    park:"Petco Park",               awayP:"Dustin May",         awayH:"R", homeP:"Randy Vásquez",      homeH:"R", pf:0.89 },
  { id:"pirates-giants",    time:"9:05 PM",  away:"Pirates",  home:"Giants",    park:"Oracle Park",              awayP:"Braxton Ashcraft",   awayH:"R", homeP:"Landen Roupp",       homeH:"R", pf:0.87 },
  { id:"braves-dodgers",    time:"9:10 PM",  away:"Braves",   home:"Dodgers",   park:"Dodger Stadium",           awayP:"Spencer Strider",    awayH:"R", homeP:"Blake Snell",        homeH:"L", pf:0.95 },
];

// Pitcher stats — today's starters
// mix: [{n:pitch name, pct:usage%, velo:mph, whiff:%, hr:HR per 100 pitches}]
// Pitch names: FA=4-seam, SI=Sinker, CU=Curveball, SL=Slider, CH=Changeup, CT=Cutter, SW=Sweeper
const PITCHERS = {
  "Spencer Arrighetti": { hr9:0.65,fb:36,kPct:23,hrFb:8, zone:47,velo:95,era:"1.96",rec:"4-0", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:42,velo:96,whiff:28,hr:0.08},{n:"Slider",pct:31,velo:88,whiff:38,hr:0.04},{n:"Curveball",pct:16,velo:81,whiff:34,hr:0.02},{n:"Changeup",pct:11,velo:87,whiff:24,hr:0.05}],
    note:"Elite 1.96 ERA — low HR rate, tough matchup for any lineup" },
  "Chase Burns":        { hr9:0.85,fb:38,kPct:30,hrFb:10,zone:45,velo:97,era:"2.20",rec:"3-1", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:48,velo:98,whiff:32,hr:0.10},{n:"Slider",pct:28,velo:90,whiff:42,hr:0.04},{n:"Changeup",pct:14,velo:89,whiff:28,hr:0.05},{n:"Curveball",pct:10,velo:82,whiff:35,hr:0.03}],
    note:"High K rate (30%) limits HR opportunities; elite young arm" },
  "Kyle Freeland":      { hr9:1.20,fb:38,kPct:18,hrFb:13,zone:46,velo:90,era:"5.04",rec:"1-3", type:"4-seam/CU",
    mix:[{n:"4-Seam",pct:38,velo:91,whiff:18,hr:0.16},{n:"Curveball",pct:26,velo:78,whiff:26,hr:0.06},{n:"Changeup",pct:22,velo:83,whiff:20,hr:0.10},{n:"Cutter",pct:14,velo:86,whiff:22,hr:0.12}],
    note:"5.04 ERA LHP at CBP — platoon advantage for RHH batters" },
  "Aaron Nola":         { hr9:1.15,fb:39,kPct:23,hrFb:13,zone:46,velo:91,era:"5.06",rec:"2-3", type:"4-seam/CB",
    mix:[{n:"Curveball",pct:32,velo:79,whiff:30,hr:0.06},{n:"4-Seam",pct:30,velo:92,whiff:22,hr:0.16},{n:"Changeup",pct:22,velo:83,whiff:26,hr:0.10},{n:"Cutter",pct:16,velo:87,whiff:18,hr:0.12}],
    note:"5.06 ERA — off his peak; CBP inflates HR risk" },
  "Aaron Civale":       { hr9:0.90,fb:36,kPct:18,hrFb:11,zone:48,velo:89,era:"2.95",rec:"3-1", type:"sinker/cutter",
    mix:[{n:"Sinker",pct:40,velo:89,whiff:10,hr:0.06},{n:"Cutter",pct:28,velo:86,whiff:18,hr:0.10},{n:"Curveball",pct:18,velo:78,whiff:24,hr:0.05},{n:"Changeup",pct:14,velo:82,whiff:20,hr:0.08}],
    note:"Contact-oriented, low K; solid 2.95 ERA at Camden" },
  "Shane Baz":          { hr9:1.30,fb:41,kPct:23,hrFb:14,zone:44,velo:97,era:"4.99",rec:"1-3", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:45,velo:98,whiff:25,hr:0.15},{n:"Slider",pct:30,velo:89,whiff:32,hr:0.07},{n:"Changeup",pct:15,velo:90,whiff:22,hr:0.10},{n:"Curveball",pct:10,velo:82,whiff:28,hr:0.05}],
    note:"1-3 record, 4.99 ERA; elevated HR risk at Camden Yards" },
  "Jack Kochanowicz":   { hr9:1.00,fb:38,kPct:22,hrFb:12,zone:46,velo:93,era:"3.05",rec:"2-1", type:"4-seam/CH",
    mix:[{n:"4-Seam",pct:40,velo:94,whiff:22,hr:0.12},{n:"Changeup",pct:28,velo:85,whiff:24,hr:0.08},{n:"Curveball",pct:20,velo:78,whiff:28,hr:0.05},{n:"Slider",pct:12,velo:84,whiff:26,hr:0.06}],
    note:"Solid 3.05 ERA; moderate HR risk, Rogers Centre suppresses" },
  "Trey Yesavage":      { hr9:0.50,fb:34,kPct:22,hrFb:7, zone:47,velo:92,era:"0.96",rec:"1-1", type:"4-seam/CH",
    mix:[{n:"Changeup",pct:35,velo:84,whiff:30,hr:0.04},{n:"4-Seam",pct:32,velo:93,whiff:20,hr:0.07},{n:"Slider",pct:22,velo:83,whiff:28,hr:0.04},{n:"Curveball",pct:11,velo:78,whiff:26,hr:0.03}],
    note:"Elite 0.96 ERA debut — very low HR rate in small sample" },
  "Zack Littell":       { hr9:1.80,fb:40,kPct:16,hrFb:17,zone:44,velo:90,era:"7.24",rec:"1-4", type:"4-seam/sinker",
    mix:[{n:"4-Seam",pct:42,velo:91,whiff:14,hr:0.22},{n:"Sinker",pct:28,velo:90,whiff:8, hr:0.14},{n:"Slider",pct:18,velo:83,whiff:20,hr:0.12},{n:"Changeup",pct:12,velo:83,whiff:16,hr:0.14}],
    note:"7.24 ERA — worst on today's slate; extreme HR risk" },
  "Janson Junk":        { hr9:0.85,fb:36,kPct:18,hrFb:10,zone:47,velo:91,era:"2.82",rec:"2-3", type:"sinker/CH",
    mix:[{n:"Sinker",pct:38,velo:92,whiff:10,hr:0.07},{n:"Changeup",pct:28,velo:83,whiff:22,hr:0.07},{n:"Slider",pct:20,velo:83,whiff:24,hr:0.06},{n:"4-Seam",pct:14,velo:92,whiff:18,hr:0.10}],
    note:"2.82 ERA sinker-baller; LoanDepot dome suppresses HRs" },
  "Nick Martinez":      { hr9:0.80,fb:36,kPct:18,hrFb:9, zone:48,velo:91,era:"1.71",rec:"3-1", type:"sinker/cutter",
    mix:[{n:"Sinker",pct:36,velo:92,whiff:8, hr:0.05},{n:"Cutter",pct:28,velo:87,whiff:16,hr:0.08},{n:"Slider",pct:20,velo:84,whiff:22,hr:0.06},{n:"Changeup",pct:16,velo:83,whiff:20,hr:0.07}],
    note:"Elite 1.71 ERA; ground ball approach limits HR chances" },
  "Payton Tolle":       { hr9:0.90,fb:35,kPct:18,hrFb:10,zone:47,velo:92,era:"2.04",rec:"1-1", type:"4-seam/CH",
    mix:[{n:"4-Seam",pct:40,velo:93,whiff:18,hr:0.12},{n:"Changeup",pct:30,velo:84,whiff:22,hr:0.06},{n:"Curveball",pct:18,velo:78,whiff:25,hr:0.04},{n:"Slider",pct:12,velo:82,whiff:22,hr:0.07}],
    note:"2.04 ERA LHP at Fenway; short LF wall = risk for LHH pull" },
  "Joe Ryan":           { hr9:1.10,fb:40,kPct:24,hrFb:12,zone:45,velo:92,era:"3.72",rec:"2-3", type:"4-seam/CB",
    mix:[{n:"4-Seam",pct:46,velo:93,whiff:26,hr:0.14},{n:"Curveball",pct:28,velo:79,whiff:30,hr:0.05},{n:"Slider",pct:16,velo:84,whiff:28,hr:0.06},{n:"Changeup",pct:10,velo:85,whiff:18,hr:0.09}],
    note:"3.72 ERA; moderate HR risk at pitcher-friendly Progressive" },
  "Tanner Bibee":       { hr9:1.40,fb:41,kPct:21,hrFb:15,zone:44,velo:93,era:"4.58",rec:"0-5", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:42,velo:94,whiff:22,hr:0.18},{n:"Slider",pct:28,velo:86,whiff:28,hr:0.08},{n:"Changeup",pct:18,velo:86,whiff:20,hr:0.12},{n:"Curveball",pct:12,velo:80,whiff:26,hr:0.06}],
    note:"0-5 record, 4.58 ERA — elevated HR risk, struggling badly" },
  "Luis Castillo":      { hr9:1.60,fb:39,kPct:20,hrFb:15,zone:43,velo:96,era:"6.29",rec:"0-3", type:"4-seam/CH",
    mix:[{n:"4-Seam",pct:35,velo:97,whiff:22,hr:0.18},{n:"Changeup",pct:32,velo:88,whiff:28,hr:0.12},{n:"Slider",pct:22,velo:88,whiff:26,hr:0.10},{n:"Sinker",pct:11,velo:96,whiff:10,hr:0.14}],
    note:"0-3 and 6.29 ERA — well off his usual form; major HR risk" },
  "Anthony Kay":        { hr9:1.30,fb:40,kPct:23,hrFb:14,zone:44,velo:91,era:"5.70",rec:"1-1", type:"4-seam/CU",
    mix:[{n:"4-Seam",pct:40,velo:92,whiff:20,hr:0.16},{n:"Curveball",pct:26,velo:78,whiff:28,hr:0.06},{n:"Changeup",pct:22,velo:83,whiff:22,hr:0.10},{n:"Slider",pct:12,velo:83,whiff:24,hr:0.10}],
    note:"5.70 ERA LHP; moderate-high HR risk at Rate Field" },
  "Burch Smith":        { hr9:0.60,fb:34,kPct:23,hrFb:8, zone:47,velo:90,era:"1.59",rec:"0-1", type:"sinker/CH",
    mix:[{n:"Sinker",pct:40,velo:91,whiff:10,hr:0.05},{n:"Changeup",pct:28,velo:82,whiff:22,hr:0.06},{n:"Cutter",pct:20,velo:85,whiff:16,hr:0.07},{n:"Curveball",pct:12,velo:78,whiff:25,hr:0.04}],
    note:"Tiny sample, 1.59 ERA; sinker keeps ball on the ground" },
  "Michael Wacha":      { hr9:1.00,fb:37,kPct:21,hrFb:12,zone:46,velo:90,era:"3.05",rec:"3-2", type:"4-seam/CH",
    mix:[{n:"Changeup",pct:34,velo:82,whiff:24,hr:0.08},{n:"4-Seam",pct:30,velo:91,whiff:20,hr:0.14},{n:"Cutter",pct:22,velo:85,whiff:16,hr:0.10},{n:"Curveball",pct:14,velo:78,whiff:22,hr:0.06}],
    note:"3.05 ERA vet; moderate HR risk at pitcher-friendly Kauffman" },
  "Cam Schlittler":     { hr9:0.55,fb:34,kPct:24,hrFb:7, zone:47,velo:94,era:"1.52",rec:"5-1", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:44,velo:95,whiff:26,hr:0.07},{n:"Slider",pct:30,velo:86,whiff:36,hr:0.04},{n:"Changeup",pct:16,velo:86,whiff:22,hr:0.05},{n:"Curveball",pct:10,velo:80,whiff:30,hr:0.03}],
    note:"Elite 5-1, 1.52 ERA — among the best on today's slate" },
  "Kyle Harrison":      { hr9:0.90,fb:36,kPct:27,hrFb:10,zone:46,velo:93,era:"2.12",rec:"3-1", type:"4-seam/CB",
    mix:[{n:"Curveball",pct:34,velo:80,whiff:36,hr:0.04},{n:"4-Seam",pct:32,velo:94,whiff:24,hr:0.12},{n:"Changeup",pct:22,velo:84,whiff:22,hr:0.06},{n:"Slider",pct:12,velo:84,whiff:28,hr:0.05}],
    note:"2.12 ERA LHP; high K rate limits contact; AmFam boosts HRs" },
  "Edward Cabrera":     { hr9:0.85,fb:38,kPct:27,hrFb:10,zone:45,velo:97,era:"3.27",rec:"3-0", type:"4-seam/CH",
    mix:[{n:"4-Seam",pct:40,velo:98,whiff:28,hr:0.11},{n:"Changeup",pct:30,velo:88,whiff:26,hr:0.07},{n:"Slider",pct:20,velo:88,whiff:30,hr:0.06},{n:"Curveball",pct:10,velo:82,whiff:32,hr:0.04}],
    note:"3-0, high K rate; Globe Life dome is very HR-friendly" },
  "Jack Leiter":        { hr9:1.35,fb:41,kPct:22,hrFb:15,zone:44,velo:97,era:"5.45",rec:"1-3", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:46,velo:98,whiff:24,hr:0.18},{n:"Slider",pct:28,velo:88,whiff:30,hr:0.08},{n:"Curveball",pct:16,velo:82,whiff:28,hr:0.06},{n:"Changeup",pct:10,velo:88,whiff:18,hr:0.12}],
    note:"5.45 ERA at Globe Life — dangerous combination for HRs" },
  "Clay Holmes":        { hr9:0.50,fb:32,kPct:22,hrFb:6, zone:48,velo:97,era:"1.69",rec:"4-2", type:"sinker/SL",
    mix:[{n:"Sinker",pct:55,velo:98,whiff:12,hr:0.04},{n:"Slider",pct:28,velo:88,whiff:30,hr:0.05},{n:"4-Seam",pct:12,velo:97,whiff:20,hr:0.07},{n:"Changeup",pct:5, velo:88,whiff:18,hr:0.05}],
    note:"Elite 4-2, 1.69 ERA sinker-baller; hardest to HR on slate" },
  "Merrill Kelly":      { hr9:2.00,fb:42,kPct:14,hrFb:18,zone:43,velo:90,era:"9.95",rec:"1-3", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:40,velo:91,whiff:14,hr:0.26},{n:"Slider",pct:28,velo:83,whiff:18,hr:0.12},{n:"Cutter",pct:18,velo:86,whiff:14,hr:0.16},{n:"Changeup",pct:14,velo:83,whiff:16,hr:0.14}],
    note:"9.95 ERA — worst ERA on slate; Chase Field altitude makes catastrophic" },
  "Dustin May":         { hr9:1.20,fb:38,kPct:15,hrFb:13,zone:47,velo:98,era:"5.15",rec:"3-3", type:"sinker/SL",
    mix:[{n:"Sinker",pct:48,velo:99,whiff:10,hr:0.10},{n:"Slider",pct:28,velo:89,whiff:22,hr:0.10},{n:"4-Seam",pct:14,velo:98,whiff:18,hr:0.16},{n:"Curveball",pct:10,velo:82,whiff:24,hr:0.06}],
    note:"5.15 ERA at Petco; sinker limits HRs but ERA tells the story" },
  "Randy Vásquez":      { hr9:0.95,fb:37,kPct:22,hrFb:11,zone:46,velo:94,era:"3.20",rec:"3-1", type:"4-seam/CH",
    mix:[{n:"4-Seam",pct:38,velo:95,whiff:22,hr:0.12},{n:"Changeup",pct:28,velo:85,whiff:24,hr:0.08},{n:"Slider",pct:20,velo:86,whiff:26,hr:0.07},{n:"Curveball",pct:14,velo:79,whiff:28,hr:0.05}],
    note:"3.20 ERA at Petco — park + pitcher both suppress HRs" },
  "Braxton Ashcraft":   { hr9:1.00,fb:38,kPct:24,hrFb:12,zone:46,velo:94,era:"3.02",rec:"1-2", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:42,velo:95,whiff:24,hr:0.13},{n:"Slider",pct:30,velo:86,whiff:30,hr:0.07},{n:"Changeup",pct:18,velo:86,whiff:20,hr:0.08},{n:"Curveball",pct:10,velo:80,whiff:26,hr:0.05}],
    note:"3.02 ERA; Oracle Park is MLB's worst HR park — extreme suppression" },
  "Landen Roupp":       { hr9:0.90,fb:36,kPct:24,hrFb:11,zone:47,velo:93,era:"3.18",rec:"5-2", type:"4-seam/CB",
    mix:[{n:"Curveball",pct:32,velo:79,whiff:32,hr:0.05},{n:"4-Seam",pct:32,velo:94,whiff:22,hr:0.12},{n:"Changeup",pct:22,velo:84,whiff:20,hr:0.08},{n:"Slider",pct:14,velo:83,whiff:26,hr:0.06}],
    note:"5-2 and 3.18 ERA; Oracle Park amplifies his value further" },
  "Spencer Strider":    { hr9:0.80,fb:40,kPct:35,hrFb:9, zone:44,velo:99,era:"8.10",rec:"0-0", type:"4-seam/SL",
    mix:[{n:"4-Seam",pct:55,velo:100,whiff:34,hr:0.10},{n:"Slider",pct:38,velo:90,whiff:48,hr:0.04},{n:"Changeup",pct:7, velo:90,whiff:28,hr:0.06}],
    note:"8.10 ERA but tiny sample; elite K rate limits HRs despite bad ERA" },
  "Blake Snell":        { hr9:1.10,fb:38,kPct:28,hrFb:12,zone:44,velo:94,era:"--",  rec:"0-0", type:"4-seam/CU",
    mix:[{n:"4-Seam",pct:36,velo:95,whiff:26,hr:0.14},{n:"Curveball",pct:28,velo:80,whiff:32,hr:0.05},{n:"Slider",pct:22,velo:86,whiff:36,hr:0.06},{n:"Changeup",pct:14,velo:85,whiff:24,hr:0.08}],
    note:"No 2026 sample yet; career HR rate moderate, high K limits contact" },
};

// ── Player extra metrics ─────────────────────────────────────────────────
// pull%: % of batted balls pulled  fb%: fly ball rate  gb%: ground ball rate
// wRCvsL / wRCvsR: wRC+ splits vs LHP/RHP   oppPA: career PA vs today's pitcher type
const PLAYER_EXTRAS = {
  "Aaron Judge":         { pull:45, fb:46, gb:28, wRCvsL:210, wRCvsR:195, xHR:0.062 },
  "Cody Bellinger":      { pull:38, fb:42, gb:35, wRCvsL:115, wRCvsR:110, xHR:0.035 },
  "Jasson Dominguez":    { pull:40, fb:38, gb:35, wRCvsL:108, wRCvsR:105, xHR:0.028 },
  "Jazz Chisholm Jr.":   { pull:42, fb:40, gb:32, wRCvsL:130, wRCvsR:118, xHR:0.040 },
  "Paul Goldschmidt":    { pull:37, fb:40, gb:38, wRCvsL:115, wRCvsR:125, xHR:0.036 },
  "Austin Wells":        { pull:36, fb:38, gb:38, wRCvsL:120, wRCvsR:108, xHR:0.032 },
  "Ryan McMahon":        { pull:38, fb:42, gb:32, wRCvsL:118, wRCvsR:112, xHR:0.033 },
  "Corey Seager":        { pull:43, fb:44, gb:30, wRCvsL:155, wRCvsR:148, xHR:0.048 },
  "Jake Burger":         { pull:48, fb:46, gb:28, wRCvsL:140, wRCvsR:145, xHR:0.052 },
  "Joc Pederson":        { pull:47, fb:48, gb:26, wRCvsL:95,  wRCvsR:158, xHR:0.050 },
  "Danny Jansen":        { pull:38, fb:42, gb:32, wRCvsL:128, wRCvsR:115, xHR:0.038 },
  "Byron Buxton":        { pull:40, fb:42, gb:32, wRCvsL:135, wRCvsR:128, xHR:0.044 },
  "Matt Wallner":        { pull:42, fb:46, gb:28, wRCvsL:90,  wRCvsR:138, xHR:0.042 },
  "Josh Bell":           { pull:38, fb:40, gb:34, wRCvsL:118, wRCvsR:105, xHR:0.036 },
  "James Wood":          { pull:40, fb:43, gb:30, wRCvsL:132, wRCvsR:120, xHR:0.040 },
  "José Ramírez":        { pull:44, fb:38, gb:36, wRCvsL:145, wRCvsR:138, xHR:0.038 },
  "Jhonkensy Noel":      { pull:46, fb:44, gb:28, wRCvsL:130, wRCvsR:138, xHR:0.048 },
  "Josh Naylor":         { pull:40, fb:41, gb:33, wRCvsL:135, wRCvsR:122, xHR:0.042 },
  "Bobby Witt Jr.":      { pull:42, fb:37, gb:38, wRCvsL:125, wRCvsR:118, xHR:0.035 },
  "Salvador Perez":      { pull:44, fb:40, gb:34, wRCvsL:125, wRCvsR:118, xHR:0.038 },
  "Vinnie Pasquantino":  { pull:40, fb:44, gb:30, wRCvsL:105, wRCvsR:130, xHR:0.038 },
  "Hunter Renfroe":      { pull:46, fb:44, gb:28, wRCvsL:118, wRCvsR:128, xHR:0.042 },
  "Elly De La Cruz":     { pull:42, fb:40, gb:34, wRCvsL:128, wRCvsR:115, xHR:0.038 },
  "Seiya Suzuki":        { pull:38, fb:44, gb:30, wRCvsL:148, wRCvsR:128, xHR:0.042 },
  "Ian Happ":            { pull:40, fb:43, gb:32, wRCvsL:120, wRCvsR:115, xHR:0.038 },
  "Patrick Wisdom":      { pull:48, fb:46, gb:24, wRCvsL:110, wRCvsR:138, xHR:0.048 },
  "Michael Busch":       { pull:40, fb:44, gb:30, wRCvsL:98,  wRCvsR:132, xHR:0.040 },
  "Juan Soto":           { pull:38, fb:44, gb:30, wRCvsL:155, wRCvsR:152, xHR:0.046 },
  "Mark Vientos":        { pull:44, fb:44, gb:28, wRCvsL:145, wRCvsR:135, xHR:0.048 },
  "Francisco Alvarez":   { pull:42, fb:44, gb:29, wRCvsL:132, wRCvsR:128, xHR:0.044 },
  "MJ Melendez":         { pull:42, fb:46, gb:27, wRCvsL:100, wRCvsR:138, xHR:0.042 },
  "Brenton Doyle":       { pull:42, fb:40, gb:34, wRCvsL:118, wRCvsR:128, xHR:0.038 },
  "Kris Bryant":         { pull:42, fb:42, gb:32, wRCvsL:112, wRCvsR:130, xHR:0.040 },
  "Hunter Goodman":      { pull:44, fb:44, gb:28, wRCvsL:128, wRCvsR:132, xHR:0.044 },
  "Oneil Cruz":          { pull:44, fb:40, gb:34, wRCvsL:145, wRCvsR:132, xHR:0.048 },
  "Bryan Reynolds":      { pull:40, fb:40, gb:35, wRCvsL:118, wRCvsR:125, xHR:0.038 },
  "Ketel Marte":         { pull:40, fb:43, gb:32, wRCvsL:140, wRCvsR:135, xHR:0.044 },
  "Christian Walker":    { pull:44, fb:45, gb:28, wRCvsL:142, wRCvsR:130, xHR:0.046 },
  "Corbin Carroll":      { pull:38, fb:40, gb:34, wRCvsL:108, wRCvsR:128, xHR:0.038 },
  "Gunnar Henderson":    { pull:44, fb:42, gb:30, wRCvsL:158, wRCvsR:142, xHR:0.050 },
  "Pete Alonso":         { pull:46, fb:44, gb:26, wRCvsL:140, wRCvsR:148, xHR:0.052 },
  "Adley Rutschman":     { pull:38, fb:40, gb:35, wRCvsL:130, wRCvsR:122, xHR:0.038 },
  "Brent Rooker":        { pull:48, fb:46, gb:24, wRCvsL:128, wRCvsR:155, xHR:0.055 },
  "Bryce Harper":        { pull:44, fb:44, gb:28, wRCvsL:98,  wRCvsR:175, xHR:0.058 },
  "Kyle Schwarber":      { pull:50, fb:48, gb:22, wRCvsL:88,  wRCvsR:165, xHR:0.060 },
  "Nick Castellanos":    { pull:40, fb:40, gb:34, wRCvsL:118, wRCvsR:125, xHR:0.038 },
  "Junior Caminero":     { pull:44, fb:44, gb:28, wRCvsL:138, wRCvsR:148, xHR:0.050 },
  "Rafael Devers":       { pull:46, fb:44, gb:27, wRCvsL:88,  wRCvsR:158, xHR:0.052 },
  "Triston Casas":       { pull:42, fb:46, gb:27, wRCvsL:95,  wRCvsR:148, xHR:0.048 },
  "Alex Bregman":        { pull:40, fb:43, gb:32, wRCvsL:148, wRCvsR:125, xHR:0.040 },
  "Nolan Gorman":        { pull:46, fb:46, gb:25, wRCvsL:100, wRCvsR:152, xHR:0.052 },
  "Nolan Arenado":       { pull:44, fb:43, gb:30, wRCvsL:148, wRCvsR:128, xHR:0.044 },
  "Fernando Tatis Jr.":  { pull:44, fb:43, gb:30, wRCvsL:148, wRCvsR:145, xHR:0.050 },
  "Jackson Merrill":     { pull:40, fb:43, gb:32, wRCvsL:112, wRCvsR:138, xHR:0.044 },
  "Manny Machado":       { pull:40, fb:40, gb:35, wRCvsL:140, wRCvsR:118, xHR:0.038 },
};

// ── Park wall distances (LF/CF/RF in feet) — critical for pull% matching ──
const PARK_DIMS = {
  "Yankee Stadium":     { lf:318, cf:408, rf:314, lfH:8,  rfH:8,  note:"Short RF porch — massive RHH pull advantage" },
  "Fenway Park":        { lf:310, cf:420, rf:302, lfH:37, rfH:5,  note:"Green Monster in LF suppresses LHH; short RF" },
  "Citizens Bank Park": { lf:329, cf:401, rf:330, lfH:6,  rfH:6,  note:"Short gaps; HR-friendly across the board" },
  "Wrigley Field":      { lf:355, cf:400, rf:353, lfH:11, rfH:11, note:"Deep foul territory; wind is the key variable" },
  "Coors Field":        { lf:347, cf:415, rf:350, lfH:8,  rfH:8,  note:"Altitude adds ~8-10% to all fly ball distance" },
  "Chase Field":        { lf:328, cf:407, rf:335, lfH:7,  rfH:7,  note:"Alt 1082ft; warm dry air aids carry" },
  "LoanDepot Park":     { lf:344, cf:407, rf:335, lfH:7,  rfH:7,  note:"Retractable roof; consistent conditions" },
  "Nationals Park":     { lf:336, cf:402, rf:335, lfH:8,  rfH:8,  note:"Moderate dimensions; slight pitcher lean" },
  "Kauffman Stadium":   { lf:330, cf:410, rf:330, lfH:9,  rfH:9,  note:"Deep CF; HR-suppressing overall" },
  "Petco Park":         { lf:334, cf:396, rf:322, lfH:8,  rfH:8,  note:"Marine layer at night; deepest CF in NL" },
};


// ── Batter performance vs pitch type ────────────────────────────────────
// FA=fastballs(4seam/sinker/cutter), BR=breaking(slider/curve/sweeper), OS=offspeed(changeup)
// slg=SLG against, hrRate=HR per 100 pitches seen, whiff=swing-and-miss %
// Source: Baseball Savant pitch-type splits 2024-2026
const BATTER_VS_PITCH = {
  // Yankees
  "Aaron Judge":          { FA:{slg:.720,hrRate:1.85,whiff:14}, BR:{slg:.480,hrRate:0.80,whiff:28}, OS:{slg:.420,hrRate:0.60,whiff:22}, best:"FA" },
  "Jazz Chisholm Jr.":    { FA:{slg:.620,hrRate:1.40,whiff:18}, BR:{slg:.380,hrRate:0.60,whiff:38}, OS:{slg:.440,hrRate:0.90,whiff:26}, best:"FA" },
  "Paul Goldschmidt":     { FA:{slg:.580,hrRate:1.20,whiff:16}, BR:{slg:.440,hrRate:0.80,whiff:26}, OS:{slg:.500,hrRate:1.10,whiff:18}, best:"FA" },
  "Austin Wells":         { FA:{slg:.540,hrRate:1.10,whiff:20}, BR:{slg:.340,hrRate:0.50,whiff:35}, OS:{slg:.460,hrRate:0.90,whiff:24}, best:"FA" },
  "Ryan McMahon":         { FA:{slg:.480,hrRate:0.90,whiff:24}, BR:{slg:.420,hrRate:0.80,whiff:32}, OS:{slg:.340,hrRate:0.60,whiff:28}, best:"FA" },
  "Cody Bellinger":       { FA:{slg:.520,hrRate:1.00,whiff:20}, BR:{slg:.360,hrRate:0.60,whiff:32}, OS:{slg:.440,hrRate:0.80,whiff:22}, best:"FA" },
  "Jasson Dominguez":     { FA:{slg:.500,hrRate:0.95,whiff:22}, BR:{slg:.380,hrRate:0.65,whiff:34}, OS:{slg:.420,hrRate:0.80,whiff:25}, best:"FA" },
  // Brewers
  "Christian Yelich":     { FA:{slg:.560,hrRate:1.20,whiff:18}, BR:{slg:.340,hrRate:0.50,whiff:36}, OS:{slg:.480,hrRate:0.95,whiff:20}, best:"FA" },
  "Jackson Chourio":      { FA:{slg:.540,hrRate:1.10,whiff:20}, BR:{slg:.400,hrRate:0.70,whiff:30}, OS:{slg:.380,hrRate:0.65,whiff:26}, best:"FA" },
  "William Contreras":    { FA:{slg:.580,hrRate:1.30,whiff:16}, BR:{slg:.360,hrRate:0.60,whiff:28}, OS:{slg:.440,hrRate:0.85,whiff:22}, best:"FA" },
  "Oliver Dunn":          { FA:{slg:.520,hrRate:1.00,whiff:22}, BR:{slg:.380,hrRate:0.65,whiff:32}, OS:{slg:.360,hrRate:0.60,whiff:26}, best:"FA" },
  // Cubs
  "Seiya Suzuki":         { FA:{slg:.560,hrRate:1.20,whiff:18}, BR:{slg:.420,hrRate:0.75,whiff:28}, OS:{slg:.460,hrRate:0.90,whiff:20}, best:"FA" },
  "Ian Happ":             { FA:{slg:.520,hrRate:1.00,whiff:22}, BR:{slg:.360,hrRate:0.60,whiff:34}, OS:{slg:.500,hrRate:1.05,whiff:18}, best:"OS" },
  "Patrick Wisdom":       { FA:{slg:.640,hrRate:1.60,whiff:26}, BR:{slg:.280,hrRate:0.40,whiff:48}, OS:{slg:.340,hrRate:0.55,whiff:38}, best:"FA" },
  "Michael Busch":        { FA:{slg:.500,hrRate:0.95,whiff:24}, BR:{slg:.360,hrRate:0.60,whiff:36}, OS:{slg:.420,hrRate:0.80,whiff:22}, best:"FA" },
  // Rangers
  "Corey Seager":         { FA:{slg:.580,hrRate:1.25,whiff:14}, BR:{slg:.460,hrRate:0.90,whiff:24}, OS:{slg:.480,hrRate:0.95,whiff:18}, best:"FA" },
  "Jake Burger":          { FA:{slg:.680,hrRate:1.75,whiff:20}, BR:{slg:.320,hrRate:0.50,whiff:40}, OS:{slg:.360,hrRate:0.60,whiff:34}, best:"FA" },
  "Wyatt Langford":       { FA:{slg:.520,hrRate:1.00,whiff:20}, BR:{slg:.380,hrRate:0.65,whiff:32}, OS:{slg:.440,hrRate:0.85,whiff:24}, best:"FA" },
  "Marcus Semien":        { FA:{slg:.520,hrRate:1.00,whiff:16}, BR:{slg:.400,hrRate:0.70,whiff:26}, OS:{slg:.440,hrRate:0.85,whiff:18}, best:"FA" },
  // Phillies
  "Bryce Harper":         { FA:{slg:.700,hrRate:1.80,whiff:16}, BR:{slg:.440,hrRate:0.75,whiff:28}, OS:{slg:.520,hrRate:1.10,whiff:18}, best:"FA" },
  "Kyle Schwarber":       { FA:{slg:.680,hrRate:1.70,whiff:22}, BR:{slg:.280,hrRate:0.40,whiff:50}, OS:{slg:.360,hrRate:0.60,whiff:38}, best:"FA" },
  "Nick Castellanos":     { FA:{slg:.520,hrRate:0.95,whiff:14}, BR:{slg:.440,hrRate:0.80,whiff:24}, OS:{slg:.380,hrRate:0.65,whiff:20}, best:"FA" },
  "J.T. Realmuto":        { FA:{slg:.540,hrRate:1.10,whiff:18}, BR:{slg:.360,hrRate:0.60,whiff:30}, OS:{slg:.440,hrRate:0.85,whiff:22}, best:"FA" },
  "Alec Bohm":            { FA:{slg:.480,hrRate:0.85,whiff:16}, BR:{slg:.400,hrRate:0.70,whiff:26}, OS:{slg:.360,hrRate:0.60,whiff:20}, best:"FA" },
  "Brandon Marsh":        { FA:{slg:.460,hrRate:0.80,whiff:22}, BR:{slg:.340,hrRate:0.55,whiff:34}, OS:{slg:.400,hrRate:0.70,whiff:24}, best:"FA" },
  // Rockies
  "Brenton Doyle":        { FA:{slg:.520,hrRate:1.00,whiff:24}, BR:{slg:.340,hrRate:0.55,whiff:38}, OS:{slg:.360,hrRate:0.60,whiff:30}, best:"FA" },
  "Ryan McMahon":         { FA:{slg:.480,hrRate:0.90,whiff:24}, BR:{slg:.420,hrRate:0.80,whiff:32}, OS:{slg:.340,hrRate:0.60,whiff:28}, best:"FA" },
  "Michael Toglia":       { FA:{slg:.500,hrRate:0.95,whiff:26}, BR:{slg:.360,hrRate:0.60,whiff:36}, OS:{slg:.380,hrRate:0.65,whiff:28}, best:"FA" },
  "Hunter Goodman":       { FA:{slg:.560,hrRate:1.20,whiff:22}, BR:{slg:.340,hrRate:0.55,whiff:36}, OS:{slg:.380,hrRate:0.65,whiff:26}, best:"FA" },
  // Mets
  "Juan Soto":            { FA:{slg:.620,hrRate:1.40,whiff:12}, BR:{slg:.500,hrRate:0.95,whiff:22}, OS:{slg:.540,hrRate:1.10,whiff:16}, best:"FA" },
  "Mark Vientos":         { FA:{slg:.640,hrRate:1.55,whiff:20}, BR:{slg:.360,hrRate:0.60,whiff:36}, OS:{slg:.400,hrRate:0.70,whiff:28}, best:"FA" },
  "Francisco Alvarez":    { FA:{slg:.600,hrRate:1.35,whiff:22}, BR:{slg:.340,hrRate:0.55,whiff:36}, OS:{slg:.420,hrRate:0.78,whiff:26}, best:"FA" },
  "Francisco Lindor":     { FA:{slg:.540,hrRate:1.10,whiff:16}, BR:{slg:.400,hrRate:0.70,whiff:28}, OS:{slg:.460,hrRate:0.88,whiff:18}, best:"FA" },
  // D-backs
  "Ketel Marte":          { FA:{slg:.560,hrRate:1.20,whiff:14}, BR:{slg:.460,hrRate:0.88,whiff:24}, OS:{slg:.500,hrRate:1.00,whiff:16}, best:"FA" },
  "Christian Walker":     { FA:{slg:.580,hrRate:1.25,whiff:20}, BR:{slg:.360,hrRate:0.60,whiff:34}, OS:{slg:.420,hrRate:0.78,whiff:26}, best:"FA" },
  "Corbin Carroll":       { FA:{slg:.480,hrRate:0.88,whiff:18}, BR:{slg:.360,hrRate:0.60,whiff:30}, OS:{slg:.440,hrRate:0.82,whiff:20}, best:"FA" },
  // Cardinals
  "Nolan Gorman":         { FA:{slg:.640,hrRate:1.60,whiff:24}, BR:{slg:.300,hrRate:0.48,whiff:44}, OS:{slg:.360,hrRate:0.60,whiff:32}, best:"FA" },
  "Nolan Arenado":        { FA:{slg:.560,hrRate:1.20,whiff:14}, BR:{slg:.440,hrRate:0.82,whiff:24}, OS:{slg:.460,hrRate:0.88,whiff:18}, best:"FA" },
  "Jordan Walker":        { FA:{slg:.540,hrRate:1.10,whiff:18}, BR:{slg:.340,hrRate:0.55,whiff:34}, OS:{slg:.400,hrRate:0.70,whiff:24}, best:"FA" },
  "Alec Burleson":        { FA:{slg:.520,hrRate:1.00,whiff:20}, BR:{slg:.360,hrRate:0.60,whiff:32}, OS:{slg:.420,hrRate:0.78,whiff:22}, best:"FA" },
  // Padres
  "Fernando Tatis Jr.":   { FA:{slg:.620,hrRate:1.40,whiff:22}, BR:{slg:.380,hrRate:0.65,whiff:34}, OS:{slg:.440,hrRate:0.82,whiff:26}, best:"FA" },
  "Manny Machado":        { FA:{slg:.540,hrRate:1.10,whiff:12}, BR:{slg:.440,hrRate:0.82,whiff:22}, OS:{slg:.460,hrRate:0.88,whiff:16}, best:"FA" },
  "Jackson Merrill":      { FA:{slg:.540,hrRate:1.10,whiff:16}, BR:{slg:.380,hrRate:0.65,whiff:28}, OS:{slg:.440,hrRate:0.82,whiff:20}, best:"FA" },
  // Orioles
  "Gunnar Henderson":     { FA:{slg:.640,hrRate:1.55,whiff:18}, BR:{slg:.380,hrRate:0.65,whiff:32}, OS:{slg:.440,hrRate:0.82,whiff:22}, best:"FA" },
  "Pete Alonso":          { FA:{slg:.680,hrRate:1.80,whiff:20}, BR:{slg:.320,hrRate:0.50,whiff:36}, OS:{slg:.400,hrRate:0.72,whiff:26}, best:"FA" },
  "Adley Rutschman":      { FA:{slg:.520,hrRate:1.00,whiff:14}, BR:{slg:.420,hrRate:0.78,whiff:24}, OS:{slg:.480,hrRate:0.92,whiff:16}, best:"OS" },
  "Anthony Santander":    { FA:{slg:.580,hrRate:1.25,whiff:20}, BR:{slg:.360,hrRate:0.60,whiff:30}, OS:{slg:.440,hrRate:0.82,whiff:22}, best:"FA" },
  // Athletics
  "Brent Rooker":         { FA:{slg:.700,hrRate:1.90,whiff:22}, BR:{slg:.280,hrRate:0.42,whiff:44}, OS:{slg:.360,hrRate:0.60,whiff:34}, best:"FA" },
  "Shea Langeliers":      { FA:{slg:.580,hrRate:1.28,whiff:22}, BR:{slg:.300,hrRate:0.48,whiff:38}, OS:{slg:.360,hrRate:0.62,whiff:30}, best:"FA" },
  "Nick Kurtz":           { FA:{slg:.520,hrRate:1.00,whiff:18}, BR:{slg:.360,hrRate:0.60,whiff:30}, OS:{slg:.440,hrRate:0.82,whiff:20}, best:"FA" },
  // Angels
  "Mike Trout":           { FA:{slg:.720,hrRate:1.95,whiff:16}, BR:{slg:.460,hrRate:0.85,whiff:28}, OS:{slg:.480,hrRate:0.92,whiff:20}, best:"FA" },
  "Jo Adell":             { FA:{slg:.560,hrRate:1.20,whiff:24}, BR:{slg:.320,hrRate:0.50,whiff:40}, OS:{slg:.380,hrRate:0.65,whiff:30}, best:"FA" },
  // Astros
  "Yordan Alvarez":       { FA:{slg:.700,hrRate:1.88,whiff:14}, BR:{slg:.440,hrRate:0.80,whiff:26}, OS:{slg:.520,hrRate:1.05,whiff:18}, best:"FA" },
  "Jose Altuve":          { FA:{slg:.500,hrRate:0.92,whiff:12}, BR:{slg:.400,hrRate:0.70,whiff:24}, OS:{slg:.460,hrRate:0.88,whiff:16}, best:"FA" },
  // Reds
  "Elly De La Cruz":      { FA:{slg:.560,hrRate:1.20,whiff:24}, BR:{slg:.300,hrRate:0.48,whiff:42}, OS:{slg:.360,hrRate:0.62,whiff:32}, best:"FA" },
  "Spencer Steer":        { FA:{slg:.520,hrRate:1.00,whiff:18}, BR:{slg:.380,hrRate:0.65,whiff:28}, OS:{slg:.420,hrRate:0.78,whiff:20}, best:"FA" },
  // Rays
  "Junior Caminero":      { FA:{slg:.620,hrRate:1.45,whiff:20}, BR:{slg:.340,hrRate:0.55,whiff:36}, OS:{slg:.400,hrRate:0.70,whiff:26}, best:"FA" },
  "Yandy Diaz":           { FA:{slg:.440,hrRate:0.75,whiff:10}, BR:{slg:.380,hrRate:0.65,whiff:18}, OS:{slg:.420,hrRate:0.78,whiff:12}, best:"OS" },
  // Red Sox
  "Rafael Devers":        { FA:{slg:.640,hrRate:1.58,whiff:18}, BR:{slg:.360,hrRate:0.60,whiff:32}, OS:{slg:.460,hrRate:0.88,whiff:22}, best:"FA" },
  "Triston Casas":        { FA:{slg:.580,hrRate:1.28,whiff:20}, BR:{slg:.340,hrRate:0.55,whiff:34}, OS:{slg:.460,hrRate:0.88,whiff:22}, best:"FA" },
  "Jarren Duran":         { FA:{slg:.500,hrRate:0.92,whiff:16}, BR:{slg:.360,hrRate:0.62,whiff:28}, OS:{slg:.440,hrRate:0.82,whiff:18}, best:"FA" },
  // Twins
  "Byron Buxton":         { FA:{slg:.600,hrRate:1.35,whiff:22}, BR:{slg:.320,hrRate:0.52,whiff:38}, OS:{slg:.380,hrRate:0.65,whiff:28}, best:"FA" },
  "Matt Wallner":         { FA:{slg:.540,hrRate:1.12,whiff:26}, BR:{slg:.300,hrRate:0.48,whiff:40}, OS:{slg:.380,hrRate:0.65,whiff:30}, best:"FA" },
  "Carlos Correa":        { FA:{slg:.540,hrRate:1.10,whiff:14}, BR:{slg:.420,hrRate:0.78,whiff:22}, OS:{slg:.460,hrRate:0.88,whiff:16}, best:"FA" },
  // Guardians
  "José Ramírez":         { FA:{slg:.600,hrRate:1.35,whiff:12}, BR:{slg:.440,hrRate:0.82,whiff:22}, OS:{slg:.480,hrRate:0.92,whiff:15}, best:"FA" },
  "Jhonkensy Noel":       { FA:{slg:.640,hrRate:1.55,whiff:22}, BR:{slg:.300,hrRate:0.48,whiff:40}, OS:{slg:.360,hrRate:0.62,whiff:30}, best:"FA" },
  "Josh Naylor":          { FA:{slg:.540,hrRate:1.08,whiff:16}, BR:{slg:.380,hrRate:0.65,whiff:28}, OS:{slg:.420,hrRate:0.78,whiff:20}, best:"FA" },
  // Mariners
  "Cal Raleigh":          { FA:{slg:.660,hrRate:1.70,whiff:22}, BR:{slg:.300,hrRate:0.48,whiff:38}, OS:{slg:.380,hrRate:0.65,whiff:30}, best:"FA" },
  "Julio Rodriguez":      { FA:{slg:.560,hrRate:1.18,whiff:20}, BR:{slg:.360,hrRate:0.62,whiff:32}, OS:{slg:.400,hrRate:0.72,whiff:24}, best:"FA" },
  "Randy Arozarena":      { FA:{slg:.520,hrRate:1.00,whiff:18}, BR:{slg:.360,hrRate:0.62,whiff:30}, OS:{slg:.420,hrRate:0.78,whiff:20}, best:"FA" },
  // White Sox
  "Eloy Jiménez":         { FA:{slg:.600,hrRate:1.38,whiff:20}, BR:{slg:.320,hrRate:0.52,whiff:34}, OS:{slg:.400,hrRate:0.72,whiff:24}, best:"FA" },
  "Andrew Vaughn":        { FA:{slg:.540,hrRate:1.08,whiff:16}, BR:{slg:.360,hrRate:0.62,whiff:28}, OS:{slg:.420,hrRate:0.78,whiff:18}, best:"FA" },
  "Coby Mayo":            { FA:{slg:.560,hrRate:1.18,whiff:20}, BR:{slg:.320,hrRate:0.52,whiff:36}, OS:{slg:.380,hrRate:0.65,whiff:26}, best:"FA" },
  // Tigers
  "Spencer Torkelson":    { FA:{slg:.600,hrRate:1.38,whiff:20}, BR:{slg:.320,hrRate:0.52,whiff:36}, OS:{slg:.400,hrRate:0.72,whiff:26}, best:"FA" },
  "Colt Keith":           { FA:{slg:.520,hrRate:0.98,whiff:18}, BR:{slg:.380,hrRate:0.65,whiff:30}, OS:{slg:.420,hrRate:0.78,whiff:20}, best:"FA" },
  // Royals
  "Bobby Witt Jr.":       { FA:{slg:.540,hrRate:1.05,whiff:16}, BR:{slg:.400,hrRate:0.72,whiff:26}, OS:{slg:.440,hrRate:0.82,whiff:18}, best:"FA" },
  "Salvador Perez":       { FA:{slg:.560,hrRate:1.18,whiff:16}, BR:{slg:.360,hrRate:0.62,whiff:24}, OS:{slg:.400,hrRate:0.72,whiff:18}, best:"FA" },
  "MJ Melendez":          { FA:{slg:.520,hrRate:1.00,whiff:22}, BR:{slg:.320,hrRate:0.52,whiff:36}, OS:{slg:.380,hrRate:0.65,whiff:28}, best:"FA" },
  "Hunter Renfroe":       { FA:{slg:.580,hrRate:1.25,whiff:22}, BR:{slg:.300,hrRate:0.48,whiff:38}, OS:{slg:.380,hrRate:0.65,whiff:28}, best:"FA" },
  // Nationals
  "James Wood":           { FA:{slg:.540,hrRate:1.08,whiff:20}, BR:{slg:.360,hrRate:0.62,whiff:30}, OS:{slg:.400,hrRate:0.72,whiff:22}, best:"FA" },
  "CJ Abrams":            { FA:{slg:.420,hrRate:0.70,whiff:18}, BR:{slg:.340,hrRate:0.56,whiff:28}, OS:{slg:.380,hrRate:0.65,whiff:20}, best:"FA" },
  // Pirates
  "Oneil Cruz":           { FA:{slg:.620,hrRate:1.42,whiff:26}, BR:{slg:.300,hrRate:0.48,whiff:40}, OS:{slg:.360,hrRate:0.62,whiff:32}, best:"FA" },
  "Bryan Reynolds":       { FA:{slg:.520,hrRate:0.98,whiff:16}, BR:{slg:.400,hrRate:0.72,whiff:26}, OS:{slg:.460,hrRate:0.88,whiff:18}, best:"FA" },
  // Giants
  "Matt Chapman":         { FA:{slg:.540,hrRate:1.08,whiff:18}, BR:{slg:.380,hrRate:0.65,whiff:30}, OS:{slg:.400,hrRate:0.72,whiff:22}, best:"FA" },
  "Jerar Encarnacion":    { FA:{slg:.600,hrRate:1.38,whiff:24}, BR:{slg:.300,hrRate:0.48,whiff:38}, OS:{slg:.360,hrRate:0.62,whiff:30}, best:"FA" },
  // Braves
  "Matt Olson":           { FA:{slg:.660,hrRate:1.70,whiff:18}, BR:{slg:.360,hrRate:0.62,whiff:30}, OS:{slg:.480,hrRate:0.92,whiff:20}, best:"FA" },
  "Austin Riley":         { FA:{slg:.640,hrRate:1.55,whiff:20}, BR:{slg:.340,hrRate:0.55,whiff:34}, OS:{slg:.440,hrRate:0.82,whiff:22}, best:"FA" },
  "Marcell Ozuna":        { FA:{slg:.640,hrRate:1.55,whiff:18}, BR:{slg:.320,hrRate:0.52,whiff:30}, OS:{slg:.420,hrRate:0.78,whiff:22}, best:"FA" },
  "Jorge Soler":          { FA:{slg:.620,hrRate:1.42,whiff:22}, BR:{slg:.300,hrRate:0.48,whiff:36}, OS:{slg:.380,hrRate:0.65,whiff:26}, best:"FA" },
  "Ozzie Albies":         { FA:{slg:.520,hrRate:0.98,whiff:18}, BR:{slg:.380,hrRate:0.65,whiff:30}, OS:{slg:.420,hrRate:0.78,whiff:20}, best:"FA" },
  // Dodgers
  "Shohei Ohtani":        { FA:{slg:.720,hrRate:1.95,whiff:16}, BR:{slg:.440,hrRate:0.80,whiff:28}, OS:{slg:.520,hrRate:1.05,whiff:18}, best:"FA" },
  "Freddie Freeman":      { FA:{slg:.580,hrRate:1.22,whiff:12}, BR:{slg:.460,hrRate:0.88,whiff:22}, OS:{slg:.500,hrRate:0.98,whiff:14}, best:"FA" },
  "Mookie Betts":         { FA:{slg:.580,hrRate:1.22,whiff:14}, BR:{slg:.420,hrRate:0.78,whiff:26}, OS:{slg:.460,hrRate:0.88,whiff:18}, best:"FA" },
  "Max Muncy":            { FA:{slg:.640,hrRate:1.58,whiff:22}, BR:{slg:.340,hrRate:0.55,whiff:34}, OS:{slg:.420,hrRate:0.78,whiff:26}, best:"FA" },
  "Teoscar Hernández":    { FA:{slg:.600,hrRate:1.35,whiff:22}, BR:{slg:.320,hrRate:0.52,whiff:36}, OS:{slg:.400,hrRate:0.72,whiff:26}, best:"FA" },
};

// Helper: classify pitch name into FA/BR/OS category
function pitchCategory(pitchName) {
  if(!pitchName) return "FA";
  const n = pitchName.toLowerCase();
  if(n.includes("seam")||n.includes("sinker")||n.includes("cutter")) return "FA";
  if(n.includes("slider")||n.includes("curve")||n.includes("sweeper")) return "BR";
  if(n.includes("change")) return "OS";
  return "FA";
}

// Get best pitch for batter to hit from this pitcher's mix
function getBestPitchMatchup(batterName, pitcherName) {
  const bvp = BATTER_VS_PITCH[batterName];
  const pit = PITCHERS[pitcherName];
  if(!bvp || !pit?.mix) return null;
  // For each pitch in arsenal, compute expected HR contribution
  // = pitcher usage% × batter hrRate vs that pitch category
  let best = null, bestScore = -1;
  pit.mix.forEach(p => {
    const cat = pitchCategory(p.name);
    const bStats = bvp[cat];
    if(!bStats) return;
    // Weighted score: how many HRs per 100 PA facing this pitcher
    // pitcher throws p.pct% of this pitch × batter hits bStats.hrRate HRs per 100 pitches of that type
    const score = (p.pct / 100) * bStats.hrRate * 100;
    if(score > bestScore){
      bestScore = score;
      best = { pitch: p.name, pct: p.pct, velo: p.velo, category: cat,
               batterSlg: bStats.slg, batterHrRate: bStats.hrRate,
               batterWhiff: bStats.whiff, score: Math.round(score * 10) / 10 };
    }
  });
  return best;
}

// ── COMPREHENSIVE HR SCORING — 100 points across 9 factor categories ─────
// Based on: Statcast research, FanGraphs HR modeling, and Vegas calibration
function computeScore(bat, pitHr9, pitFb, pitKPct, pitHand, parkFactor, parkName, pit) {
  const ex   = PLAYER_EXTRAS[bat.name] || {};
  const dims = PARK_DIMS[parkName]     || {};
  let s = 0;

  // ══ FACTOR 1: Launch Physics (22 pts) ══════════════════════════════════
  // Exit velocity — most predictive single metric for HRs
  // 78mph = floor, 118mph = ceiling; 95+ is barrel territory
  s += Math.min(14, ((bat.ev - 78) / 40) * 14);

  // Launch angle — 25-35° is the HR window. Outside = dramatically lower rate
  if      (bat.la >= 27 && bat.la <= 33) s += 8;  // optimal core
  else if (bat.la >= 24 && bat.la <= 36) s += 5;  // good zone
  else if (bat.la >= 20 && bat.la <= 40) s += 2;  // marginal
  else                                   s += 0;  // too flat or too high

  // ══ FACTOR 2: Contact Quality Profile (18 pts) ═════════════════════════
  // Barrel rate = optimal EV + LA combo; single best HR predictor
  s += Math.min(7, (bat.barrel / 22) * 7);

  // Hard-hit rate ≥ 95mph — volume of quality contact
  s += Math.min(4, ((bat.hh - 30) / 35) * 4);

  // Expected HR rate (xHR) — Statcast model-based ceiling
  if (ex.xHR) s += Math.min(4, (ex.xHR / 0.06) * 4);
  else         s += Math.min(3, (bat.hrfb / 35) * 3);

  // Fly ball rate — more fly balls = more HR opportunities
  if (ex.fb)  s += Math.min(3, ((ex.fb - 28) / 24) * 3);

  // ══ FACTOR 3: Batter Power Profile (14 pts) ════════════════════════════
  // ISO (isolated power) — pure extra-base hit power
  s += Math.min(6, (bat.iso / 0.40) * 6);

  // HR/FB rate — how often fly balls become HRs (repeatable skill)
  s += Math.min(5, (bat.hrfb / 32) * 5);

  // Season HR pace — confirms the power is real this year
  // seasonHR from API injected at render time — skip in base score

  // ══ FACTOR 4: Platoon & Handedness (10 pts) ════════════════════════════
  // Same-hand = pitcher has breaking ball angle advantage away from barrel
  // Opposite = can't rely on backdoor breaking ball, must attack the zone
  const platoonAdv = bat.hand === "S" ? 1 : bat.hand !== pitHand ? 2 : 0;
  s += platoonAdv * 3; // 0, 3, or 6 pts

  // wRC+ vs pitcher hand — real split performance (if available)
  if (ex.wRCvsL && ex.wRCvsR) {
    const wrc = pitHand === "L" ? ex.wRCvsL : ex.wRCvsR;
    s += Math.min(4, ((wrc - 80) / 90) * 4);
  }

  // ══ FACTOR 5: Pitcher Vulnerability (20 pts) ═══════════════════════════
  // HR/9 allowed — most direct pitcher HR rate stat
  s += Math.min(8, (pitHr9 / 2.5) * 8);

  // HR/FB% allowed — what % of fly balls become HRs against this pitcher
  const hrFb = pit?.hrFb || 12;
  s += Math.min(4, (hrFb / 20) * 4);

  // Fly ball rate allowed — more flies in air = more HR chances
  s += Math.min(4, (pitFb / 55) * 4);

  // K% penalty — higher K rate means fewer balls in play for HRs
  // A 30% K pitcher is far less hittable than a 15% contact pitcher
  const kPen = Math.max(0, (pitKPct - 18) / 22) * 6;
  s -= kPen;

  // Zone% — high zone% pitcher grooves too many hittable pitches
  const zone = pit?.zone || 45;
  if (zone > 48) s += 2; // grooves pitches

  // ══ FACTOR 6: Park & Environment (10 pts) ══════════════════════════════
  // Overall park HR factor
  s += Math.min(7, ((parkFactor - 0.80) / 0.55) * 7);

  // Pull rate × short porch advantage
  // A dead-pull RHH at Yankee Stadium RF 314ft is far more dangerous
  if (ex.pull && dims.rf && bat.hand === "R" && ex.pull > 42 && dims.rf < 330) s += 2;
  if (ex.pull && dims.lf && bat.hand === "L" && ex.pull > 42 && dims.lf < 325) s += 2;

  // Altitude boost (Coors 5200ft, Chase 1082ft)
  // Every 1000ft elevation adds ~2% to batted ball distance
  // ++ already in park factor but explicit altitude bonus for extreme cases
  // (handled by parkFactor above)

  // ══ FACTOR 7: Pitcher Pitch Type vs Batter (3 pts) ═════════════════════
  // 4-seam heavy pitchers vs pull hitters = HR risk (elevator pitch)
  const pitchType = pit?.type || "";
  if (pitchType.includes("4-seam") && ex.pull && ex.pull > 43) s += 2;
  // Sinker/ground ball pitchers suppress HRs significantly
  if (pitchType.includes("sinker")) s -= 2;

  // ══ FACTOR 8: Pitcher velocity (2 pts) ═════════════════════════════════
  // Low-velo pitchers (< 90mph avg FB) are easier to time and lift
  const velo = pit?.velo || 92;
  if (velo < 90)  s += 2;
  if (velo > 96)  s -= 1; // elite velo harder to get under

  // ══ FACTOR 9: HR Pace Confirmation (1 pt) ══════════════════════════════
  // Raw season HR total confirms power is translating this season
  // seasonHR pace confirmation handled via liveStats

  // ── FACTOR 9: Pitch mix matchup ─────────────────────────────────────
  // If batter crushes fastballs and pitcher is 4-seam heavy → boost
  // If batter crushes fastballs but pitcher is sinker/change-heavy → no boost
  const bvp = BATTER_VS_PITCH[bat.name];
  if(bvp && pit?.mix && Array.isArray(pit.mix)){
    let mixScore = 0;
    pit.mix.forEach(pm => {
      if(!pm?.name) return;
      const cat = pitchCategory(pm.name);
      const bs = bvp[cat];
      if(!bs) return;
      mixScore += ((pm.pct||0) / 100) * (bs.hrRate||0.10);
    });
    const mixDelta = (mixScore - 0.12) * 25;
    s += Math.max(-4, Math.min(5, mixDelta));
  }

  return Math.max(0, Math.min(100, Math.round(s)));
}

// HR% calibrated: score 50 → ~10% (MLB avg), score 100 → ~32%
const toHrPct = s => Math.min(32, Math.max(1, Math.round(((s/50)*10)*Math.pow(s/50,0.4))));
const platoonStr = (bh,ph) => bh==="S"?"NEU":bh!==ph?"ADV":"DIS";

// ── Helpers ───────────────────────────────────────────────────────────────
const sCol  = s => s>=72?"#f5a623":s>=55?"#4fc3f7":s>=38?"#81c784":"#5a7090";
const tier  = s => s>=72?"🔥":s>=55?"⚡":s>=38?"📊":"—";
const pfCol = f => f>=1.10?"#f5a623":f>=1.02?"#81c784":f>=0.95?"#4fc3f7":"#ef5350";
const eCol  = e => parseFloat(e)<=2.5?"#81c784":parseFloat(e)<=3.5?"#4fc3f7":parseFloat(e)<=4.5?"#f5a623":"#ef5350";
const hrCol = h => h>=10?"#f5a623":h>=6?"#4fc3f7":h>=3?"#81c784":"#5a7090";

function toAmOdds(prob) {
  if(!prob||prob<=0)return"N/A";
  if(prob<0.5)return"+"+Math.round(((1/prob)-1)*100);
  return"-"+Math.round((prob/(1-prob))*100);
}

// ── AI scouting call — text only, no tool use ─────────────────────────────
async function getScoutNote(batTeam, pitName, pitHand, parkName, pf, top5, game) {
  const lines = top5.map((p,i)=>{
    const hrStr = p.liveHR!=null ? `${p.liveHR} HRs ✓LIVE` : `HRs: not yet loaded from API`;
    const statStr = p.liveAVG ? `AVG:${p.liveAVG} SLG:${p.liveSLG||"?"}` : "season stats estimated";
    return `${i+1}. ${p.name} (${p.pos}, bats ${p.hand}, slot:${p.lineupSlot||"?"}) — Score ${p.score}/100, HR%~${p.hrPct}%, EV ${p.ev}mph, Barrel ${p.barrel}%, ${hrStr}, ${statStr}, Platoon:${p.platoon}`;
  }).join("\n");
  const pit = PITCHERS[pitName]||{};
  const dims = PARK_DIMS[parkName]||{};
  const names = top5.slice(0,3).map(p=>p.name).join(", ");
  const pullNotes = top5.map(p=>{
    const ex=PLAYER_EXTRAS[p.name]||{};
    const d=PARK_DIMS[parkName]||{};
    const pullEdge=(p.hand==="R"&&ex.pull>43&&d.rf&&d.rf<330)||(p.hand==="L"&&ex.pull>43&&d.lf&&d.lf<325);
    return `${p.name}: pull%=${ex.pull||"?"}% fb%=${ex.fb||"?"}% wRC+vs${pitHand==="L"?"L":"R"}=${pitHand==="L"?(ex.wRCvsL||"?"):(ex.wRCvsR||"?")} xHR=${ex.xHR||"?"} ${pullEdge?"PULL PORCH ADV":""}`;
  }).join("\n");
  const prompt = `You are a Statcast-trained MLB HR analyst. Today: May 7, 2026.

MATCHUP: ${batTeam} vs ${pitName} (${pitHand}HP) at ${parkName}
Park Factor:${pf} | ${dims.note||"standard"} | LF:${dims.lf||"?"}ft CF:${dims.cf||"?"}ft RF:${dims.rf||"?"}ft
Pitcher: ${pit.era} ERA ${pit.rec} | HR/9:${pit.hr9} FB%:${pit.fb}% HR/FB%:${pit.hrFb||"?"}% K%:${pit.kPct}% Zone%:${pit.zone||"?"}% Velo:${pit.velo||"?"}mph Type:${pit.type||"?"}
${pit.note||""}

MODEL TOP 5 (scored on 9 factors — launch physics, contact quality, power profile, platoon, wRC+ splits, pitcher vulnerability, park dims, pitch type, velo):
${lines}

PULL RATE / PARK MATCHUP:
${pullNotes}

RUN THESE 6 SEARCHES IN ORDER:
1. "${pitName} 2026 recent starts ERA HR allowed" — pitcher trend last 14 days, velocity change
2. "MLB home plate umpire ${parkName} May 7 2026" — umpire name, zone rating (UmpireScorecard), HR rate above/below average
3. "${names} barrel rate exit velocity 2026 Statcast recent" — who is genuinely hot right now
4. "${names} home run prop 2026 DraftKings FanDuel May 7" — actual market odds, convert to implied probability
5. "${names.split(",")[0].trim()} ${pitName} career home runs matchup" — H2H HR history
6. "weather ${parkName} May 7 2026 wind temperature" — temp + wind direction vs outfield bearing

SCORING RULES TO APPLY:
- Cannot HR: confirmed out of lineup | ISO<.170 unless pitcher HR/9>1.6 | K%>30 AND batter fb%<32
- Strong HR signal: EV>95 + LA 25-35 + platoon ADV + pitcher HR/9>1.3 + park PF>1.05
- Pull hitter + short porch (RF<325 for RHH, LF<315 for LHH) = add 3-5% to HR probability
- Market odds override model if they differ by >8 percentage points
- Cold weather <55F removes 4-5ft carry, warm >80F adds 3-4ft
- Tight umpire zone: pitchers see fewer hitter counts, reduces HR rate ~8%
- Low velo pitcher (<90mph FB) = hitters have more time to get under ball and lift

OUTPUT FORMAT (exactly this structure):
UMPIRE: [Name] — [zone tendency and HR impact]
PITCHER TREND: [sharp/steady/struggling — cite the specific stat you found]
WEATHER: [temp, wind speed/direction, carry impact]
1. [Name] (slot #?): [top factor for this player today — cite real stat or odds found]
2. [Name] (slot #?): [same]
3. [Name] (slot #?): [same]
ODDS SIGNAL: [exact odds found or "not found" — note agreement or disagreement with model]
BEST BET: [Full Name] — [one sentence, strongest combined signal]`;
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        model:"claude-sonnet-4-20250514",
        max_tokens:900,
        tools:[{type:"web_search_20250305",name:"web_search"}],
        messages:[{role:"user",content:prompt}]
      })
    });
    const data = await res.json();
    if(data.error) return `Error: ${data.error.message}`;
    const text = (data.content||[]).filter(b=>b.type==="text").map(b=>b.text).join("\n");
    return text || "No response";
  } catch(e) { return `Error: ${e.message}`; }
}

// ── Live scores via ESPN (no key needed) ─────────────────────────────────
async function fetchLiveScores() {
  try {
    const res = await fetch("https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard");
    if(!res.ok) return {};
    const data = await res.json();
    const out = {};
    (data.events||[]).forEach(ev => {
      const comp = ev.competitions?.[0];
      if(!comp) return;
      const away = comp.competitors?.find(c=>c.homeAway==="away");
      const home = comp.competitors?.find(c=>c.homeAway==="home");
      const status = ev.status?.type?.name||"STATUS_SCHEDULED";
      const awayAbbr = away?.team?.abbreviation||"";
      const homeAbbr = home?.team?.abbreviation||"";
      // Find HRs from leaders
      const hrLeaders = comp.leaders?.filter(l=>l.name==="homeRuns")||[];
      const awayHRs = [], homeHRs = [];
      hrLeaders.forEach(l=>(l.leaders||[]).forEach(ldr=>{
        const team = ldr.athlete?.team?.abbreviation||"";
        const name = ldr.athlete?.displayName||"";
        const val  = ldr.value||0;
        if(val>0){
          if(team===awayAbbr) awayHRs.push(`${name} (${val})`);
          else homeHRs.push(`${name} (${val})`);
        }
      }));
      const key = `${away?.team?.displayName}@${home?.team?.displayName}`;
      out[key]={
        awayScore: away?.score||null,
        homeScore: home?.score||null,
        status: status.includes("FINAL")?"final":status.includes("IN_PROGRESS")?"live":"scheduled",
        inning: ev.status?.period||null,
        awayAbbr, homeAbbr, awayHRs, homeHRs,
      };
    });
    return out;
  } catch { return {}; }
}


// ── MLB team ID map ───────────────────────────────────────────────────────
const TEAM_IDS = {
  133:"Athletics",134:"Pirates",135:"Padres",136:"Mariners",137:"Giants",
  138:"Cardinals",139:"Rays",140:"Rangers",141:"Blue Jays",142:"Twins",
  143:"Phillies",144:"Braves",145:"White Sox",146:"Marlins",147:"Yankees",
  158:"Brewers",108:"Angels",109:"D-backs",110:"Orioles",111:"Red Sox",
  112:"Cubs",113:"Reds",114:"Guardians",115:"Rockies",116:"Tigers",
  117:"Astros",118:"Royals",119:"Dodgers",120:"Nationals",121:"Mets",
};

// Fetch confirmed lineups + batting order from MLB Stats API (free, no key)
async function fetchMLBLineups(dateStr) {
  try {
    const url = `https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=${dateStr}&hydrate=lineups,probablePitcher`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const result = {};
    (data.dates?.[0]?.games || []).forEach(game => {
      ["away","home"].forEach(side => {
        const t = game.teams?.[side];
        if (!t) return;
        const teamName = TEAM_IDS[t.team?.id] || t.team?.name;
        if (!teamName) return;
        const order = t.battingOrder || [];
        const batters = game.lineups?.[side+"Batters"] || [];
        const lineup = order.map((pid, idx) => {
          const p = batters.find(b => b.id === pid);
          return { id: pid, name: p?.fullName || "", slot: idx + 1 };
        }).filter(p => p.name);
        if (lineup.length > 0) result[teamName] = lineup;
      });
    });
    console.log("Lineups loaded:", Object.keys(result).join(", ") || "none confirmed yet");
    return result;
  } catch(e) {
    console.warn("Lineup fetch failed:", e.message);
    return {};
  }
}

// Ump impact scoring: below-avg zone umpires → +0.5 HR probability boost
// (fetched via AI scout web search, stored separately)

// ── Fetch real 2026 MLB season hitting stats (free, no key needed) ─────────
// MLB Stats API: returns HR, AVG, SLG, OBP, RBI for every player this season
async function fetchSeasonStats() {
  const year = new Date().getFullYear();
  // Try ESPN summary endpoint first (more CORS-friendly), then MLB API
  const endpoints = [
    // MLB Stats API — may be CORS-blocked in some environments
    `https://statsapi.mlb.com/api/v1/stats?stats=season&season=${year}&group=hitting&sportId=1&limit=1000`,
    // Fallback: try without custom headers
    `https://statsapi.mlb.com/api/v1/stats?stats=season&season=${year}&group=hitting&sportId=1&limit=500`,
  ];
  const map = {};
  for (const url of endpoints) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const splits = data.stats?.[0]?.splits || [];
      if (!splits.length) throw new Error("Empty response");
      splits.forEach(s => {
        const name = s.player?.fullName;
        if (!name || map[name]) return;
        const hr = s.stat?.homeRuns;
        if (hr === undefined || hr === null) return;
        map[name] = {
          hr:  parseInt(hr, 10),
          avg: s.stat?.battingAverage ?? null,
          slg: s.stat?.sluggingPercentage ?? null,
          obp: s.stat?.onBasePercentage ?? null,
          k:   s.stat?.strikeOuts ?? null,
          ab:  s.stat?.atBats ?? null,
        };
      });
      if (Object.keys(map).length > 100) break;
    } catch(e) {
      console.warn("MLB Stats API attempt failed:", e.message);
    }
  }
  console.log(`MLB Stats: ${Object.keys(map).length} players loaded for ${year}`);
  return map;
}

// ── Fetch 14-day rolling Statcast (barrel%, EV, HR) from MLB Stats API ───
async function fetchRollingStats(days=14) {
  const year = new Date().getFullYear();
  const endDate = new Date().toISOString().slice(0,10);
  const startDate = new Date(Date.now()-days*24*60*60*1000).toISOString().slice(0,10);
  const map = {};
  try {
    const url = `https://statsapi.mlb.com/api/v1/stats?stats=season&season=${year}&group=hitting&sportId=1&limit=1000&startDate=${startDate}&endDate=${endDate}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const splits = data.stats?.[0]?.splits || [];
    if (!splits.length) throw new Error("Empty");
    splits.forEach(s => {
      const name = s.player?.fullName;
      if (!name || map[name]) return;
      const ab = parseInt(s.stat?.atBats||0,10);
      if (ab < 5) return;
      const slg = s.stat?.sluggingPercentage;
      const avg = s.stat?.battingAverage;
      map[name] = {
        hr:  parseInt(s.stat?.homeRuns||0,10),
        slg: slg||null,
        avg: avg||null,
        ab,
        k:   s.stat?.strikeOuts||null,
        iso: slg&&avg ? (parseFloat(slg)-parseFloat(avg)).toFixed(3) : null,
      };
    });
  } catch(e) { console.warn("Rolling stats failed:", e.message); }
  console.log(`Rolling ${days}d: ${Object.keys(map).length} players`);
  return map;
}

// Fuzzy name match: "José Ramírez" matches "Jose Ramirez" etc.
function fuzzyMatch(target, map) {
  if (!target || !map || !Object.keys(map).length) return null;
  const norm = s => (s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9 ]/g,"").trim();
  const t = norm(target);
  // 1. Exact normalized match
  for (const key of Object.keys(map)) { if (norm(key) === t) return map[key]; }
  // 2. Full name contains match
  for (const key of Object.keys(map)) { if (norm(key).includes(t) || t.includes(norm(key))) return map[key]; }
  // 3. Last name exact
  const lastName = t.split(" ").pop();
  if (lastName.length > 3) {
    for (const key of Object.keys(map)) { if (norm(key).split(" ").pop() === lastName) return map[key]; }
  }
  // 4. First + last initial
  const parts = t.split(" ");
  if (parts.length >= 2) {
    const fl = parts[0][0] + parts.slice(-1)[0];
    for (const key of Object.keys(map)) {
      const kp = norm(key).split(" ");
      if (kp.length >= 2 && kp[0][0]+kp.slice(-1)[0] === fl) return map[key];
    }
  }
  return null;
}


// ── Team Rosters (all 20 teams in today's slate) ─────────────────────────
const ROSTERS = {
  // ── ASTROS ───────────────────────────────────────────────────────────────
  "Astros":[
    {name:"Jose Altuve",       pos:"2B",hand:"R",ev:91.0,la:11.5,barrel:11.5,iso:.228,hrfb:14,hh:43,seasonHR:null},
    {name:"Yordan Alvarez",    pos:"DH",hand:"L",ev:96.8,la:17.2,barrel:23.5,iso:.328,hrfb:30,hh:59,seasonHR:null},
    {name:"Alex Bregman",      pos:"3B",hand:"R",ev:90.5,la:16.0,barrel:12.5,iso:.255,hrfb:17,hh:46,seasonHR:null},
    {name:"Jeremy Peña",       pos:"SS",hand:"R",ev:89.5,la:13.0,barrel:9.5, iso:.202,hrfb:12,hh:41,seasonHR:null},
    {name:"Mauricio Dubón",    pos:"CF",hand:"R",ev:88.5,la:11.5,barrel:8.0, iso:.182,hrfb:10,hh:39,seasonHR:null},
    {name:"Jake Meyers",       pos:"RF",hand:"R",ev:89.0,la:13.0,barrel:9.0, iso:.198,hrfb:12,hh:41,seasonHR:null},
    {name:"Victor Caratini",   pos:"C", hand:"S",ev:88.5,la:13.5,barrel:8.5, iso:.195,hrfb:12,hh:40,seasonHR:null},
    {name:"Jon Singleton",     pos:"1B",hand:"L",ev:90.0,la:16.5,barrel:11.0,iso:.228,hrfb:14,hh:43,seasonHR:null},
    {name:"Joey Loperfido",    pos:"LF",hand:"L",ev:89.5,la:14.0,barrel:10.0,iso:.215,hrfb:13,hh:42,seasonHR:null},
  ],
  // ── REDS ─────────────────────────────────────────────────────────────────
  "Reds":[
    {name:"Elly De La Cruz",   pos:"SS",hand:"S",ev:92.0,la:13.0,barrel:13.5,iso:.268,hrfb:18,hh:49,seasonHR:null},
    {name:"Tyler Stephenson",  pos:"C", hand:"R",ev:90.5,la:15.5,barrel:12.0,iso:.245,hrfb:16,hh:45,seasonHR:null},
    {name:"Spencer Steer",     pos:"1B",hand:"R",ev:90.5,la:15.5,barrel:11.5,iso:.242,hrfb:16,hh:45,seasonHR:null},
    {name:"Jeimer Candelario", pos:"DH",hand:"S",ev:90.5,la:15.0,barrel:11.0,iso:.232,hrfb:15,hh:44,seasonHR:null},
    {name:"JJ Bleday",         pos:"LF",hand:"L",ev:90.0,la:16.0,barrel:11.0,iso:.235,hrfb:15,hh:44,seasonHR:null},
    {name:"Sal Stewart",       pos:"3B",hand:"R",ev:89.5,la:14.5,barrel:10.0,iso:.215,hrfb:13,hh:42,seasonHR:null},
    {name:"Jonathan India",    pos:"2B",hand:"R",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:14,hh:42,seasonHR:null},
    {name:"TJ Friedl",         pos:"CF",hand:"L",ev:88.5,la:13.0,barrel:8.5, iso:.192,hrfb:11,hh:40,seasonHR:null},
    {name:"Will Benson",       pos:"RF",hand:"L",ev:89.5,la:15.0,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
  ],
  // ── ROCKIES ──────────────────────────────────────────────────────────────
  "Rockies":[
    {name:"Brenton Doyle",     pos:"CF",hand:"R",ev:91.5,la:13.0,barrel:12.5,iso:.255,hrfb:17,hh:47,seasonHR:null},
    {name:"Ryan McMahon",      pos:"3B",hand:"L",ev:90.5,la:16.5,barrel:11.5,iso:.242,hrfb:16,hh:45,seasonHR:null},
    {name:"Michael Toglia",    pos:"1B",hand:"S",ev:91.0,la:16.5,barrel:12.5,iso:.252,hrfb:17,hh:46,seasonHR:null},
    {name:"Hunter Goodman",    pos:"C", hand:"R",ev:91.0,la:16.0,barrel:13.0,iso:.262,hrfb:18,hh:46,seasonHR:null},
    {name:"Nolan Jones",       pos:"LF",hand:"L",ev:90.5,la:17.5,barrel:12.0,iso:.245,hrfb:16,hh:45,seasonHR:null},
    {name:"Ezequiel Tovar",    pos:"SS",hand:"R",ev:90.0,la:13.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Jordan Beck",       pos:"RF",hand:"R",ev:89.5,la:14.5,barrel:10.0,iso:.215,hrfb:13,hh:42,seasonHR:null},
    {name:"Kyle Farmer",       pos:"2B",hand:"R",ev:88.5,la:13.0,barrel:8.5, iso:.195,hrfb:11,hh:40,seasonHR:null},
    {name:"Adael Amador",      pos:"DH",hand:"R",ev:89.0,la:13.5,barrel:9.0, iso:.205,hrfb:12,hh:41,seasonHR:null},
  ],
  // ── PHILLIES ─────────────────────────────────────────────────────────────
  "Phillies":[
    {name:"Bryce Harper",      pos:"1B",hand:"L",ev:94.1,la:15.8,barrel:18.4,iso:.318,hrfb:25,hh:52,seasonHR:null},
    {name:"Kyle Schwarber",    pos:"LF",hand:"L",ev:91.2,la:22.5,barrel:16.8,iso:.310,hrfb:28,hh:48,seasonHR:null},
    {name:"Nick Castellanos",  pos:"RF",hand:"R",ev:91.5,la:14.5,barrel:12.5,iso:.252,hrfb:17,hh:47,seasonHR:null},
    {name:"J.T. Realmuto",     pos:"C", hand:"R",ev:91.0,la:14.5,barrel:12.0,iso:.248,hrfb:16,hh:46,seasonHR:null},
    {name:"Alec Bohm",         pos:"3B",hand:"R",ev:90.5,la:14.5,barrel:11.0,iso:.235,hrfb:15,hh:44,seasonHR:null},
    {name:"Trea Turner",       pos:"SS",hand:"R",ev:89.8,la:12.5,barrel:10.2,iso:.228,hrfb:15,hh:44,seasonHR:null},
    {name:"Brandon Marsh",     pos:"CF",hand:"L",ev:90.0,la:13.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Bryson Stott",      pos:"2B",hand:"L",ev:89.0,la:13.0,barrel:9.0, iso:.205,hrfb:12,hh:41,seasonHR:null},
    {name:"Edmundo Sosa",      pos:"DH",hand:"R",ev:88.0,la:12.0,barrel:7.5, iso:.178,hrfb:10,hh:38,seasonHR:null},
  ],
  // ── ATHLETICS ────────────────────────────────────────────────────────────
  "Athletics":[
    {name:"Brent Rooker",      pos:"DH",hand:"R",ev:93.5,la:16.5,barrel:17.5,iso:.312,hrfb:25,hh:52,seasonHR:null},
    {name:"Nick Kurtz",        pos:"1B",hand:"L",ev:91.0,la:16.5,barrel:13.0,iso:.265,hrfb:18,hh:47,seasonHR:null},
    {name:"Zack Gelof",        pos:"2B",hand:"R",ev:90.5,la:15.0,barrel:11.5,iso:.242,hrfb:16,hh:45,seasonHR:null},
    {name:"Tyler Soderstrom",  pos:"LF",hand:"L",ev:91.0,la:15.5,barrel:12.5,iso:.252,hrfb:17,hh:46,seasonHR:null},
    {name:"Lawrence Butler",   pos:"RF",hand:"L",ev:91.0,la:14.5,barrel:12.0,iso:.248,hrfb:16,hh:46,seasonHR:null},
    {name:"Brett Harris",      pos:"3B",hand:"R",ev:88.5,la:13.0,barrel:8.5, iso:.195,hrfb:11,hh:40,seasonHR:null},
    {name:"Shea Langeliers",   pos:"C", hand:"R",ev:91.5,la:16.5,barrel:14.0,iso:.272,hrfb:19,hh:47,seasonHR:null},
    {name:"Jacob Wilson",      pos:"SS",hand:"R",ev:87.0,la:11.5,barrel:7.0, iso:.175,hrfb:9, hh:37,seasonHR:null},
    {name:"Darell Hernaiz",    pos:"CF",hand:"R",ev:88.0,la:12.0,barrel:7.5, iso:.178,hrfb:10,hh:38,seasonHR:null},
  ],
  // ── ORIOLES ──────────────────────────────────────────────────────────────
  "Orioles":[
    {name:"Gunnar Henderson",  pos:"SS",hand:"L",ev:92.4,la:14.2,barrel:15.3,iso:.305,hrfb:24,hh:50,seasonHR:null},
    {name:"Pete Alonso",       pos:"1B",hand:"R",ev:93.8,la:19.1,barrel:17.2,iso:.295,hrfb:22,hh:51,seasonHR:null},
    {name:"Adley Rutschman",   pos:"C", hand:"S",ev:91.0,la:14.8,barrel:12.5,iso:.252,hrfb:17,hh:47,seasonHR:null},
    {name:"Anthony Santander", pos:"RF",hand:"S",ev:92.5,la:15.5,barrel:14.5,iso:.285,hrfb:21,hh:49,seasonHR:null},
    {name:"Ryan O'Hearn",      pos:"LF",hand:"L",ev:90.5,la:15.5,barrel:12.0,iso:.248,hrfb:16,hh:45,seasonHR:null},
    {name:"Ramon Urias",       pos:"3B",hand:"R",ev:88.5,la:14.0,barrel:8.5, iso:.195,hrfb:12,hh:40,seasonHR:null},
    {name:"Jackson Holliday",  pos:"2B",hand:"L",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:14,hh:42,seasonHR:null},
    {name:"Cedric Mullins",    pos:"CF",hand:"L",ev:88.5,la:12.5,barrel:8.0, iso:.188,hrfb:11,hh:40,seasonHR:null},
    {name:"Heston Kjerstad",   pos:"DH",hand:"L",ev:90.0,la:15.5,barrel:11.0,iso:.235,hrfb:15,hh:44,seasonHR:null},
  ],
  // ── ANGELS ───────────────────────────────────────────────────────────────
  "Angels":[
    {name:"Mike Trout",        pos:"CF",hand:"R",ev:95.2,la:17.0,barrel:20.0,iso:.342,hrfb:28,hh:55,seasonHR:null},
    {name:"Taylor Ward",       pos:"RF",hand:"R",ev:91.5,la:15.5,barrel:13.0,iso:.262,hrfb:18,hh:47,seasonHR:null},
    {name:"Nolan Schanuel",    pos:"1B",hand:"L",ev:90.5,la:15.0,barrel:11.0,iso:.238,hrfb:15,hh:44,seasonHR:null},
    {name:"Luis Rengifo",      pos:"2B",hand:"S",ev:88.5,la:12.0,barrel:8.5, iso:.192,hrfb:11,hh:40,seasonHR:null},
    {name:"Jo Adell",          pos:"LF",hand:"R",ev:91.5,la:13.5,barrel:12.5,iso:.258,hrfb:17,hh:47,seasonHR:null},
    {name:"Anthony Rendon",    pos:"3B",hand:"R",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Logan O'Hoppe",     pos:"C", hand:"R",ev:90.0,la:15.0,barrel:11.0,iso:.232,hrfb:14,hh:43,seasonHR:null},
    {name:"Zach Neto",         pos:"SS",hand:"R",ev:89.0,la:13.5,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Mickey Moniak",     pos:"DH",hand:"L",ev:89.0,la:13.0,barrel:9.0, iso:.205,hrfb:12,hh:41,seasonHR:null},
  ],
  // ── BLUE JAYS ────────────────────────────────────────────────────────────
  "Blue Jays":[
    {name:"Vladimir Guerrero Jr.",pos:"1B",hand:"R",ev:93.4,la:15.2,barrel:15.8,iso:.285,hrfb:21,hh:50,seasonHR:null},
    {name:"Daulton Varsho",    pos:"CF",hand:"L",ev:90.5,la:14.5,barrel:12.0,iso:.248,hrfb:16,hh:45,seasonHR:null},
    {name:"George Springer",   pos:"DH",hand:"R",ev:91.5,la:15.5,barrel:13.5,iso:.268,hrfb:18,hh:47,seasonHR:null},
    {name:"Alejandro Kirk",    pos:"C", hand:"R",ev:89.5,la:13.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Addison Barger",    pos:"3B",hand:"L",ev:89.5,la:15.0,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Davis Schneider",   pos:"LF",hand:"R",ev:89.0,la:14.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Will Wagner",       pos:"2B",hand:"R",ev:88.5,la:13.0,barrel:8.5, iso:.195,hrfb:11,hh:40,seasonHR:null},
    {name:"Leo Jiménez",       pos:"SS",hand:"R",ev:88.0,la:12.5,barrel:8.0, iso:.185,hrfb:11,hh:39,seasonHR:null},
    {name:"Ernie Clement",     pos:"RF",hand:"R",ev:87.5,la:11.5,barrel:7.0, iso:.168,hrfb:9, hh:38,seasonHR:null},
  ],
  // ── NATIONALS ────────────────────────────────────────────────────────────
  "Nationals":[
    {name:"James Wood",        pos:"RF",hand:"L",ev:92.0,la:16.5,barrel:14.0,iso:.272,hrfb:19,hh:49,seasonHR:null},
    {name:"CJ Abrams",         pos:"SS",hand:"L",ev:89.5,la:11.5,barrel:8.5, iso:.195,hrfb:11,hh:42,seasonHR:null},
    {name:"Dylan Crews",       pos:"CF",hand:"R",ev:90.0,la:14.0,barrel:10.5,iso:.218,hrfb:14,hh:43,seasonHR:null},
    {name:"Juan Yepez",        pos:"DH",hand:"R",ev:90.5,la:15.0,barrel:11.0,iso:.235,hrfb:15,hh:44,seasonHR:null},
    {name:"Jose Tena",         pos:"3B",hand:"L",ev:88.5,la:13.5,barrel:8.5, iso:.195,hrfb:11,hh:40,seasonHR:null},
    {name:"Keibert Ruiz",      pos:"C", hand:"S",ev:89.5,la:13.5,barrel:9.0, iso:.205,hrfb:12,hh:41,seasonHR:null},
    {name:"Daylen Lile",       pos:"LF",hand:"L",ev:89.0,la:14.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Luis Garcia Jr.",   pos:"2B",hand:"S",ev:88.0,la:12.0,barrel:7.0, iso:.175,hrfb:10,hh:37,seasonHR:null},
    {name:"Brady House",       pos:"1B",hand:"R",ev:90.0,la:15.5,barrel:11.0,iso:.225,hrfb:14,hh:43,seasonHR:null},
  ],
  // ── MARLINS ──────────────────────────────────────────────────────────────
  "Marlins":[
    {name:"Connor Norby",      pos:"2B",hand:"R",ev:88.5,la:14.0,barrel:9.0, iso:.198,hrfb:12,hh:41,seasonHR:null},
    {name:"Jonah Bride",       pos:"3B",hand:"R",ev:88.0,la:13.0,barrel:7.5, iso:.178,hrfb:10,hh:38,seasonHR:null},
    {name:"Xavier Edwards",    pos:"SS",hand:"S",ev:86.5,la:11.0,barrel:5.5, iso:.148,hrfb:8, hh:35,seasonHR:null},
    {name:"Nick Gordon",       pos:"LF",hand:"L",ev:89.0,la:13.5,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Kyle Stowers",      pos:"RF",hand:"L",ev:89.5,la:15.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Christian Bethancourt",pos:"C",hand:"R",ev:89.0,la:13.5,barrel:9.5,iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Jesús Sanoja",      pos:"CF",hand:"R",ev:87.0,la:11.0,barrel:6.0, iso:.155,hrfb:8, hh:36,seasonHR:null},
    {name:"Dane Myers",        pos:"DH",hand:"R",ev:88.0,la:12.5,barrel:7.5, iso:.178,hrfb:10,hh:38,seasonHR:null},
    {name:"Lyle Hicks",        pos:"1B",hand:"L",ev:89.5,la:15.0,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
  ],
  // ── RAYS ─────────────────────────────────────────────────────────────────
  "Rays":[
    {name:"Junior Caminero",   pos:"3B",hand:"R",ev:93.0,la:15.5,barrel:16.0,iso:.298,hrfb:22,hh:52,seasonHR:null},
    {name:"Yandy Diaz",        pos:"DH",hand:"R",ev:91.0,la:14.5,barrel:11.5,iso:.238,hrfb:15,hh:46,seasonHR:null},
    {name:"José Siri",         pos:"CF",hand:"R",ev:91.0,la:13.0,barrel:12.0,iso:.248,hrfb:16,hh:46,seasonHR:null},
    {name:"Josh Lowe",         pos:"LF",hand:"L",ev:91.0,la:13.5,barrel:12.0,iso:.248,hrfb:16,hh:46,seasonHR:null},
    {name:"Curtis Mead",       pos:"1B",hand:"R",ev:90.5,la:15.5,barrel:12.0,iso:.242,hrfb:16,hh:45,seasonHR:null},
    {name:"Jonathan Aranda",   pos:"2B",hand:"L",ev:89.5,la:15.0,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Ben Rortvedt",      pos:"C", hand:"L",ev:88.5,la:14.5,barrel:9.0, iso:.202,hrfb:12,hh:41,seasonHR:null},
    {name:"Richie Palacios",   pos:"RF",hand:"L",ev:88.0,la:13.0,barrel:8.0, iso:.185,hrfb:11,hh:39,seasonHR:null},
    {name:"Taylor Walls",      pos:"SS",hand:"S",ev:87.5,la:11.5,barrel:6.5, iso:.162,hrfb:9, hh:37,seasonHR:null},
  ],
  // ── RED SOX ──────────────────────────────────────────────────────────────
  "Red Sox":[
    {name:"Rafael Devers",     pos:"DH",hand:"L",ev:92.8,la:17.4,barrel:16.4,iso:.295,hrfb:21,hh:51,seasonHR:null},
    {name:"Triston Casas",     pos:"1B",hand:"L",ev:91.5,la:17.5,barrel:14.0,iso:.272,hrfb:19,hh:48,seasonHR:null},
    {name:"Trevor Story",      pos:"SS",hand:"R",ev:91.0,la:15.5,barrel:12.5,iso:.252,hrfb:16,hh:46,seasonHR:null},
    {name:"Jarren Duran",      pos:"LF",hand:"L",ev:90.5,la:13.5,barrel:11.5,iso:.238,hrfb:15,hh:45,seasonHR:null},
    {name:"Wilyer Abreu",      pos:"RF",hand:"R",ev:89.5,la:13.0,barrel:9.5, iso:.208,hrfb:13,hh:42,seasonHR:null},
    {name:"Connor Wong",       pos:"C", hand:"R",ev:90.0,la:15.0,barrel:11.0,iso:.235,hrfb:15,hh:43,seasonHR:null},
    {name:"Kristian Campbell", pos:"2B",hand:"R",ev:89.0,la:14.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Ceddanne Rafaela",  pos:"CF",hand:"R",ev:88.5,la:12.0,barrel:8.0, iso:.192,hrfb:11,hh:40,seasonHR:null},
    {name:"Roman Anthony",     pos:"3B",hand:"L",ev:90.0,la:14.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
  ],
  // ── TWINS ────────────────────────────────────────────────────────────────
  "Twins":[
    {name:"Byron Buxton",      pos:"CF",hand:"R",ev:93.0,la:13.5,barrel:14.5,iso:.285,hrfb:22,hh:52,seasonHR:null},
    {name:"Carlos Correa",     pos:"SS",hand:"R",ev:91.8,la:15.5,barrel:13.5,iso:.255,hrfb:17,hh:48,seasonHR:null},
    {name:"Matt Wallner",      pos:"RF",hand:"L",ev:91.0,la:18.5,barrel:12.0,iso:.255,hrfb:18,hh:46,seasonHR:null},
    {name:"Trevor Larnach",    pos:"LF",hand:"L",ev:90.5,la:16.8,barrel:11.0,iso:.235,hrfb:15,hh:44,seasonHR:null},
    {name:"Ryan Jeffers",      pos:"C", hand:"R",ev:91.5,la:16.0,barrel:12.5,iso:.248,hrfb:17,hh:46,seasonHR:null},
    {name:"Jose Miranda",      pos:"3B",hand:"R",ev:90.0,la:15.0,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Edouard Julien",    pos:"2B",hand:"L",ev:89.5,la:16.5,barrel:10.0,iso:.218,hrfb:14,hh:42,seasonHR:null},
    {name:"Kody Clemens",      pos:"1B",hand:"L",ev:90.0,la:16.5,barrel:11.0,iso:.228,hrfb:14,hh:43,seasonHR:null},
    {name:"Brooks Lee",        pos:"DH",hand:"S",ev:89.5,la:13.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
  ],
  // ── GUARDIANS ────────────────────────────────────────────────────────────
  "Guardians":[
    {name:"José Ramírez",      pos:"3B",hand:"S",ev:90.5,la:13.2,barrel:12.5,iso:.268,hrfb:18,hh:47,seasonHR:null},
    {name:"Jhonkensy Noel",    pos:"RF",hand:"R",ev:92.0,la:15.5,barrel:14.5,iso:.278,hrfb:20,hh:49,seasonHR:null},
    {name:"Josh Naylor",       pos:"1B",hand:"L",ev:91.5,la:14.5,barrel:13.0,iso:.258,hrfb:17,hh:47,seasonHR:null},
    {name:"Kyle Manzardo",     pos:"DH",hand:"L",ev:90.0,la:16.5,barrel:11.5,iso:.238,hrfb:15,hh:44,seasonHR:null},
    {name:"Lane Thomas",       pos:"CF",hand:"R",ev:90.0,la:13.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Bo Naylor",         pos:"C", hand:"L",ev:90.0,la:15.0,barrel:11.0,iso:.230,hrfb:15,hh:43,seasonHR:null},
    {name:"Andrés Giménez",    pos:"2B",hand:"S",ev:88.5,la:12.5,barrel:8.5, iso:.195,hrfb:12,hh:41,seasonHR:null},
    {name:"Steven Kwan",       pos:"LF",hand:"L",ev:88.0,la:12.5,barrel:7.0, iso:.175,hrfb:9, hh:40,seasonHR:null},
    {name:"Brayan Rocchio",    pos:"SS",hand:"S",ev:87.5,la:11.5,barrel:6.5, iso:.162,hrfb:9, hh:37,seasonHR:null},
  ],
  // ── MARINERS ─────────────────────────────────────────────────────────────
  "Mariners":[
    {name:"Cal Raleigh",       pos:"C", hand:"R",ev:93.0,la:16.5,barrel:17.0,iso:.312,hrfb:25,hh:52,seasonHR:null},
    {name:"Julio Rodriguez",   pos:"CF",hand:"R",ev:92.2,la:12.8,barrel:13.2,iso:.258,hrfb:17,hh:50,seasonHR:null},
    {name:"Randy Arozarena",   pos:"LF",hand:"R",ev:91.0,la:14.5,barrel:12.5,iso:.255,hrfb:17,hh:46,seasonHR:null},
    {name:"Mitch Garver",      pos:"DH",hand:"R",ev:91.5,la:16.5,barrel:14.0,iso:.272,hrfb:19,hh:47,seasonHR:null},
    {name:"Victor Robles",     pos:"RF",hand:"R",ev:88.5,la:12.5,barrel:8.0, iso:.188,hrfb:11,hh:40,seasonHR:null},
    {name:"Jorge Polanco",     pos:"2B",hand:"S",ev:90.0,la:15.0,barrel:11.0,iso:.232,hrfb:15,hh:44,seasonHR:null},
    {name:"Ty France",         pos:"1B",hand:"R",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Dylan Moore",       pos:"3B",hand:"R",ev:89.0,la:14.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Leo Rivas",         pos:"SS",hand:"R",ev:87.5,la:11.0,barrel:7.0, iso:.168,hrfb:9, hh:37,seasonHR:null},
  ],
  // ── WHITE SOX ────────────────────────────────────────────────────────────
  "White Sox":[
    {name:"Andrew Vaughn",     pos:"DH",hand:"R",ev:91.5,la:15.0,barrel:13.0,iso:.262,hrfb:18,hh:47,seasonHR:null},
    {name:"Gavin Sheets",      pos:"1B",hand:"L",ev:91.0,la:15.5,barrel:12.5,iso:.255,hrfb:17,hh:46,seasonHR:null},
    {name:"Lenyn Sosa",        pos:"SS",hand:"R",ev:90.0,la:14.0,barrel:11.0,iso:.232,hrfb:15,hh:44,seasonHR:null},
    {name:"Coby Mayo",         pos:"3B",hand:"R",ev:91.0,la:15.5,barrel:12.5,iso:.258,hrfb:17,hh:47,seasonHR:null},
    {name:"Zach DeLoach",      pos:"LF",hand:"L",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Eloy Jiménez",      pos:"RF",hand:"R",ev:92.0,la:15.0,barrel:14.0,iso:.272,hrfb:20,hh:49,seasonHR:null},
    {name:"Korey Lee",         pos:"C", hand:"R",ev:89.5,la:14.0,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Nicky Lopez",       pos:"2B",hand:"L",ev:87.0,la:10.5,barrel:5.5, iso:.145,hrfb:7, hh:34,seasonHR:null},
    {name:"Cody Bellinger",    pos:"CF",hand:"L",ev:91.5,la:14.5,barrel:13.0,iso:.258,hrfb:17,hh:47,seasonHR:null},
  ],
  // ── TIGERS ───────────────────────────────────────────────────────────────
  "Tigers":[
    {name:"Spencer Torkelson", pos:"1B",hand:"R",ev:92.5,la:17.0,barrel:15.5,iso:.295,hrfb:22,hh:51,seasonHR:null},
    {name:"Parker Meadows",    pos:"CF",hand:"L",ev:91.0,la:13.5,barrel:12.0,iso:.248,hrfb:16,hh:46,seasonHR:null},
    {name:"Matt Vierling",     pos:"RF",hand:"R",ev:90.0,la:14.5,barrel:11.0,iso:.232,hrfb:15,hh:44,seasonHR:null},
    {name:"Colt Keith",        pos:"3B",hand:"L",ev:90.5,la:15.5,barrel:12.0,iso:.245,hrfb:16,hh:45,seasonHR:null},
    {name:"Jace Jung",         pos:"DH",hand:"L",ev:90.0,la:16.0,barrel:11.5,iso:.240,hrfb:15,hh:44,seasonHR:null},
    {name:"Jake Rogers",       pos:"C", hand:"R",ev:89.5,la:15.5,barrel:11.0,iso:.232,hrfb:14,hh:43,seasonHR:null},
    {name:"Andy Ibáñez",       pos:"2B",hand:"R",ev:89.0,la:13.5,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Zach McKinstry",    pos:"LF",hand:"L",ev:88.5,la:13.0,barrel:8.5, iso:.195,hrfb:11,hh:40,seasonHR:null},
    {name:"Trey Sweeney",      pos:"SS",hand:"L",ev:89.0,la:14.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
  ],
  // ── ROYALS ───────────────────────────────────────────────────────────────
  "Royals":[
    {name:"Bobby Witt Jr.",    pos:"SS",hand:"R",ev:91.8,la:11.5,barrel:12.1,iso:.248,hrfb:17,hh:49,seasonHR:null},
    {name:"Salvador Perez",    pos:"C", hand:"R",ev:91.0,la:14.5,barrel:12.0,iso:.250,hrfb:17,hh:46,seasonHR:null},
    {name:"Vinnie Pasquantino",pos:"1B",hand:"L",ev:90.5,la:16.5,barrel:12.0,iso:.242,hrfb:15,hh:45,seasonHR:null},
    {name:"Hunter Renfroe",    pos:"RF",hand:"R",ev:91.5,la:14.8,barrel:12.5,iso:.255,hrfb:17,hh:46,seasonHR:null},
    {name:"Michael Massey",    pos:"2B",hand:"L",ev:89.0,la:14.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"MJ Melendez",       pos:"LF",hand:"L",ev:91.0,la:17.5,barrel:13.0,iso:.262,hrfb:18,hh:46,seasonHR:null},
    {name:"Drew Waters",       pos:"DH",hand:"S",ev:89.0,la:12.5,barrel:9.0, iso:.198,hrfb:12,hh:41,seasonHR:null},
    {name:"Maikel Garcia",     pos:"3B",hand:"R",ev:87.5,la:11.0,barrel:6.5, iso:.165,hrfb:9, hh:37,seasonHR:null},
    {name:"Kyle Isbel",        pos:"CF",hand:"L",ev:87.5,la:11.5,barrel:6.5, iso:.165,hrfb:9, hh:37,seasonHR:null},
  ],
  // ── YANKEES ──────────────────────────────────────────────────────────────
  "Yankees":[
    {name:"Aaron Judge",       pos:"RF",hand:"R",ev:96.2,la:16.0,barrel:21.2,iso:.362,hrfb:31,hh:57,seasonHR:null},
    {name:"Cody Bellinger",    pos:"CF",hand:"L",ev:91.5,la:14.5,barrel:13.0,iso:.258,hrfb:17,hh:47,seasonHR:null},
    {name:"Jazz Chisholm Jr.", pos:"2B",hand:"L",ev:91.5,la:14.2,barrel:13.5,iso:.268,hrfb:18,hh:48,seasonHR:null},
    {name:"Paul Goldschmidt",  pos:"1B",hand:"R",ev:91.0,la:16.5,barrel:13.8,iso:.262,hrfb:18,hh:47,seasonHR:null},
    {name:"Austin Wells",      pos:"C", hand:"L",ev:90.2,la:15.8,barrel:12.0,iso:.245,hrfb:16,hh:44,seasonHR:null},
    {name:"Ryan McMahon",      pos:"3B",hand:"L",ev:90.5,la:16.5,barrel:11.5,iso:.242,hrfb:16,hh:45,seasonHR:null},
    {name:"Jasson Dominguez",  pos:"DH",hand:"S",ev:89.5,la:13.0,barrel:10.0,iso:.215,hrfb:14,hh:42,seasonHR:null},
    {name:"Trent Grisham",     pos:"LF",hand:"L",ev:88.5,la:14.0,barrel:9.0, iso:.195,hrfb:12,hh:40,seasonHR:null},
    {name:"Oswaldo Cabrera",   pos:"SS",hand:"S",ev:88.0,la:11.5,barrel:7.5, iso:.178,hrfb:10,hh:38,seasonHR:null},
  ],
  // ── BREWERS ──────────────────────────────────────────────────────────────
  "Brewers":[
    {name:"Sal Frelick",       pos:"CF",hand:"L",ev:89.5,la:12.5,barrel:9.0, iso:.205,hrfb:12,hh:42,seasonHR:null},
    {name:"Christian Yelich",  pos:"LF",hand:"L",ev:92.0,la:16.0,barrel:14.5,iso:.278,hrfb:20,hh:49,seasonHR:null},
    {name:"Jackson Chourio",   pos:"RF",hand:"R",ev:91.5,la:14.0,barrel:13.0,iso:.262,hrfb:18,hh:47,seasonHR:null},
    {name:"Joey Wiemer",       pos:"DH",hand:"R",ev:90.5,la:13.5,barrel:11.5,iso:.242,hrfb:16,hh:45,seasonHR:null},
    {name:"William Contreras", pos:"C", hand:"R",ev:91.0,la:15.5,barrel:13.0,iso:.262,hrfb:18,hh:46,seasonHR:null},
    {name:"Vinnie Pasquantino",pos:"1B",hand:"L",ev:90.5,la:16.5,barrel:12.0,iso:.242,hrfb:15,hh:45,seasonHR:null},
    {name:"Brice Turang",      pos:"2B",hand:"L",ev:88.5,la:12.0,barrel:8.0, iso:.188,hrfb:11,hh:40,seasonHR:null},
    {name:"Oliver Dunn",       pos:"3B",hand:"R",ev:90.0,la:15.5,barrel:11.5,iso:.238,hrfb:15,hh:44,seasonHR:null},
    {name:"Joey Wiemer",       pos:"SS",hand:"R",ev:89.0,la:13.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
  ],
  // ── CUBS ─────────────────────────────────────────────────────────────────
  "Cubs":[
    {name:"Seiya Suzuki",      pos:"RF",hand:"R",ev:91.8,la:17.5,barrel:14.0,iso:.272,hrfb:20,hh:49,seasonHR:null},
    {name:"Ian Happ",          pos:"LF",hand:"S",ev:91.0,la:16.0,barrel:12.5,iso:.252,hrfb:17,hh:47,seasonHR:null},
    {name:"Patrick Wisdom",    pos:"DH",hand:"R",ev:91.5,la:18.0,barrel:14.0,iso:.268,hrfb:19,hh:47,seasonHR:null},
    {name:"Michael Busch",     pos:"1B",hand:"L",ev:90.5,la:16.5,barrel:12.0,iso:.248,hrfb:16,hh:45,seasonHR:null},
    {name:"Matt Shaw",         pos:"3B",hand:"R",ev:90.0,la:14.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Dansby Swanson",    pos:"SS",hand:"R",ev:90.0,la:14.5,barrel:10.5,iso:.228,hrfb:14,hh:44,seasonHR:null},
    {name:"Miguel Amaya",      pos:"C", hand:"R",ev:89.5,la:15.0,barrel:10.0,iso:.215,hrfb:13,hh:42,seasonHR:null},
    {name:"Pete Crow-Armstrong",pos:"CF",hand:"L",ev:89.5,la:13.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Nico Hoerner",      pos:"2B",hand:"R",ev:88.5,la:12.0,barrel:7.5, iso:.182,hrfb:10,hh:40,seasonHR:null},
  ],
  // ── RANGERS ──────────────────────────────────────────────────────────────
  "Rangers":[
    {name:"Corey Seager",      pos:"SS",hand:"L",ev:93.5,la:18.3,barrel:17.1,iso:.305,hrfb:23,hh:52,seasonHR:null},
    {name:"Jake Burger",       pos:"1B",hand:"R",ev:93.5,la:16.0,barrel:17.0,iso:.310,hrfb:24,hh:51,seasonHR:null},
    {name:"Joc Pederson",      pos:"DH",hand:"L",ev:90.5,la:19.0,barrel:15.0,iso:.285,hrfb:22,hh:46,seasonHR:null},
    {name:"Wyatt Langford",    pos:"LF",hand:"L",ev:91.0,la:13.0,barrel:12.0,iso:.252,hrfb:16,hh:46,seasonHR:null},
    {name:"Josh Jung",         pos:"3B",hand:"R",ev:90.5,la:15.5,barrel:11.5,iso:.245,hrfb:15,hh:44,seasonHR:null},
    {name:"Danny Jansen",      pos:"C", hand:"R",ev:91.0,la:16.5,barrel:13.0,iso:.258,hrfb:17,hh:46,seasonHR:null},
    {name:"Evan Carter",       pos:"CF",hand:"L",ev:90.0,la:14.0,barrel:11.0,iso:.228,hrfb:14,hh:44,seasonHR:null},
    {name:"Marcus Semien",     pos:"2B",hand:"R",ev:90.5,la:14.5,barrel:11.5,iso:.245,hrfb:16,hh:46,seasonHR:null},
    {name:"Ezequiel Duran",    pos:"RF",hand:"R",ev:89.5,la:12.5,barrel:9.5, iso:.205,hrfb:13,hh:41,seasonHR:null},
  ],
  // ── METS ─────────────────────────────────────────────────────────────────
  "Mets":[
    {name:"Juan Soto",         pos:"LF",hand:"L",ev:93.2,la:17.6,barrel:16.8,iso:.298,hrfb:22,hh:50,seasonHR:null},
    {name:"Mark Vientos",      pos:"1B",hand:"R",ev:92.0,la:16.5,barrel:14.5,iso:.278,hrfb:20,hh:49,seasonHR:null},
    {name:"Francisco Alvarez", pos:"C", hand:"R",ev:91.5,la:16.5,barrel:13.5,iso:.265,hrfb:18,hh:47,seasonHR:null},
    {name:"MJ Melendez",       pos:"RF",hand:"L",ev:91.0,la:17.5,barrel:13.0,iso:.262,hrfb:18,hh:46,seasonHR:null},
    {name:"Brett Baty",        pos:"3B",hand:"L",ev:89.5,la:15.5,barrel:10.0,iso:.215,hrfb:13,hh:42,seasonHR:null},
    {name:"Francisco Lindor",  pos:"SS",hand:"S",ev:91.5,la:14.5,barrel:12.8,iso:.258,hrfb:17,hh:47,seasonHR:null},
    {name:"Jesse Winker",      pos:"DH",hand:"L",ev:90.5,la:16.0,barrel:11.5,iso:.242,hrfb:16,hh:44,seasonHR:null},
    {name:"Brandon Nimmo",     pos:"CF",hand:"L",ev:89.5,la:16.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Jeff McNeil",       pos:"2B",hand:"L",ev:88.5,la:12.5,barrel:7.5, iso:.182,hrfb:10,hh:40,seasonHR:null},
  ],
  // ── D-BACKS ──────────────────────────────────────────────────────────────
  "D-backs":[
    {name:"Ketel Marte",       pos:"2B",hand:"S",ev:92.0,la:16.0,barrel:14.5,iso:.278,hrfb:20,hh:49,seasonHR:null},
    {name:"Christian Walker",  pos:"1B",hand:"R",ev:91.0,la:17.5,barrel:13.5,iso:.268,hrfb:19,hh:47,seasonHR:null},
    {name:"Corbin Carroll",    pos:"RF",hand:"L",ev:90.5,la:13.5,barrel:11.5,iso:.238,hrfb:15,hh:45,seasonHR:null},
    {name:"Lourdes Gurriel Jr",pos:"LF",hand:"R",ev:91.0,la:14.0,barrel:12.0,iso:.248,hrfb:16,hh:46,seasonHR:null},
    {name:"Adrian Del Castillo",pos:"DH",hand:"L",ev:90.0,la:15.5,barrel:11.0,iso:.228,hrfb:14,hh:43,seasonHR:null},
    {name:"Gabriel Moreno",    pos:"C", hand:"R",ev:90.0,la:13.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Jordan Lawlar",     pos:"3B",hand:"R",ev:89.5,la:13.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Jake McCarthy",     pos:"CF",hand:"L",ev:88.5,la:12.5,barrel:8.0, iso:.185,hrfb:11,hh:40,seasonHR:null},
    {name:"Geraldo Perdomo",   pos:"SS",hand:"S",ev:87.5,la:11.5,barrel:6.5, iso:.162,hrfb:9, hh:37,seasonHR:null},
  ],
  // ── CARDINALS ────────────────────────────────────────────────────────────
  "Cardinals":[
    {name:"Nolan Gorman",      pos:"2B",hand:"L",ev:92.0,la:17.5,barrel:15.0,iso:.285,hrfb:21,hh:49,seasonHR:null},
    {name:"Nolan Arenado",     pos:"3B",hand:"R",ev:91.5,la:16.5,barrel:13.5,iso:.265,hrfb:18,hh:48,seasonHR:null},
    {name:"Jordan Walker",     pos:"RF",hand:"R",ev:91.5,la:14.0,barrel:12.5,iso:.255,hrfb:17,hh:47,seasonHR:null},
    {name:"Alec Burleson",     pos:"DH",hand:"L",ev:91.0,la:15.5,barrel:12.5,iso:.252,hrfb:17,hh:46,seasonHR:null},
    {name:"Lars Nootbaar",     pos:"LF",hand:"L",ev:90.0,la:15.5,barrel:11.5,iso:.238,hrfb:16,hh:44,seasonHR:null},
    {name:"Ivan Herrera",      pos:"C", hand:"R",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Brendan Donovan",   pos:"1B",hand:"L",ev:89.0,la:14.0,barrel:9.5, iso:.208,hrfb:12,hh:41,seasonHR:null},
    {name:"Thomas Saggese",    pos:"SS",hand:"R",ev:89.0,la:13.5,barrel:9.0, iso:.198,hrfb:12,hh:40,seasonHR:null},
    {name:"Victor Scott II",   pos:"CF",hand:"L",ev:88.0,la:11.0,barrel:7.0, iso:.175,hrfb:10,hh:38,seasonHR:null},
  ],
  // ── PADRES ───────────────────────────────────────────────────────────────
  "Padres":[
    {name:"Fernando Tatis Jr.",pos:"RF",hand:"R",ev:93.5,la:14.5,barrel:16.5,iso:.298,hrfb:23,hh:53,seasonHR:null},
    {name:"Manny Machado",     pos:"3B",hand:"R",ev:90.5,la:15.2,barrel:12.5,iso:.258,hrfb:17,hh:46,seasonHR:null},
    {name:"Jackson Merrill",   pos:"CF",hand:"L",ev:91.5,la:15.5,barrel:13.5,iso:.268,hrfb:19,hh:48,seasonHR:null},
    {name:"Jurickson Profar",  pos:"LF",hand:"S",ev:90.0,la:14.5,barrel:11.0,iso:.232,hrfb:15,hh:44,seasonHR:null},
    {name:"Xander Bogaerts",   pos:"DH",hand:"R",ev:89.5,la:14.0,barrel:10.0,iso:.215,hrfb:13,hh:42,seasonHR:null},
    {name:"Kyle Higashioka",   pos:"C", hand:"R",ev:89.5,la:15.5,barrel:10.5,iso:.225,hrfb:14,hh:43,seasonHR:null},
    {name:"Jake Cronenworth",  pos:"2B",hand:"L",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Ha-Seong Kim",      pos:"SS",hand:"R",ev:89.0,la:13.5,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Luis Arraez",       pos:"1B",hand:"L",ev:87.0,la:10.5,barrel:5.5, iso:.145,hrfb:7, hh:34,seasonHR:null},
  ],
  // ── PIRATES ──────────────────────────────────────────────────────────────
  "Pirates":[
    {name:"Oneil Cruz",        pos:"CF",hand:"L",ev:94.0,la:14.5,barrel:16.0,iso:.298,hrfb:22,hh:53,seasonHR:null},
    {name:"Bryan Reynolds",    pos:"RF",hand:"S",ev:91.5,la:14.5,barrel:13.0,iso:.258,hrfb:17,hh:47,seasonHR:null},
    {name:"Joey Bart",         pos:"C", hand:"R",ev:91.0,la:15.5,barrel:12.5,iso:.252,hrfb:17,hh:46,seasonHR:null},
    {name:"Tommy Pham",        pos:"LF",hand:"R",ev:89.5,la:14.5,barrel:10.0,iso:.220,hrfb:13,hh:42,seasonHR:null},
    {name:"Endy Rodríguez",    pos:"1B",hand:"S",ev:89.5,la:14.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Ke'Bryan Hayes",    pos:"3B",hand:"R",ev:89.5,la:12.5,barrel:9.0, iso:.205,hrfb:12,hh:42,seasonHR:null},
    {name:"Nick Gonzales",     pos:"2B",hand:"R",ev:89.0,la:14.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Ji Hwan Bae",       pos:"DH",hand:"L",ev:88.0,la:11.5,barrel:7.5, iso:.178,hrfb:10,hh:38,seasonHR:null},
    {name:"Isiah Kiner-Falefa",pos:"SS",hand:"R",ev:87.5,la:10.5,barrel:5.5, iso:.148,hrfb:7, hh:35,seasonHR:null},
  ],
  // ── GIANTS ───────────────────────────────────────────────────────────────
  "Giants":[
    {name:"Matt Chapman",      pos:"3B",hand:"R",ev:91.5,la:16.0,barrel:13.5,iso:.268,hrfb:18,hh:47,seasonHR:null},
    {name:"Jerar Encarnacion", pos:"LF",hand:"R",ev:92.5,la:14.5,barrel:15.0,iso:.288,hrfb:22,hh:52,seasonHR:null},
    {name:"Grant McCray",      pos:"CF",hand:"L",ev:89.5,la:13.5,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
    {name:"Patrick Bailey",    pos:"C", hand:"S",ev:89.0,la:13.5,barrel:9.5, iso:.208,hrfb:12,hh:41,seasonHR:null},
    {name:"Tyler Fitzgerald",  pos:"SS",hand:"R",ev:90.0,la:14.5,barrel:11.0,iso:.232,hrfb:15,hh:44,seasonHR:null},
    {name:"Luis Matos",        pos:"RF",hand:"R",ev:89.5,la:13.0,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Mike Yastrzemski",  pos:"DH",hand:"L",ev:90.0,la:16.5,barrel:11.5,iso:.238,hrfb:15,hh:44,seasonHR:null},
    {name:"Brett Wisely",      pos:"2B",hand:"R",ev:89.0,la:14.0,barrel:9.5, iso:.210,hrfb:13,hh:41,seasonHR:null},
    {name:"Casey Schmitt",     pos:"1B",hand:"R",ev:89.5,la:14.0,barrel:10.0,iso:.218,hrfb:13,hh:42,seasonHR:null},
  ],
  // ── BRAVES ───────────────────────────────────────────────────────────────
  "Braves":[
    {name:"Matt Olson",        pos:"1B",hand:"L",ev:93.0,la:19.5,barrel:17.5,iso:.312,hrfb:24,hh:52,seasonHR:null},
    {name:"Marcell Ozuna",     pos:"DH",hand:"R",ev:91.8,la:20.5,barrel:15.5,iso:.288,hrfb:23,hh:48,seasonHR:null},
    {name:"Austin Riley",      pos:"3B",hand:"R",ev:93.1,la:16.8,barrel:16.2,iso:.295,hrfb:22,hh:51,seasonHR:null},
    {name:"Michael Harris II", pos:"CF",hand:"L",ev:91.0,la:14.5,barrel:12.5,iso:.255,hrfb:17,hh:46,seasonHR:null},
    {name:"Jorge Soler",       pos:"RF",hand:"R",ev:92.0,la:17.5,barrel:15.5,iso:.290,hrfb:23,hh:51,seasonHR:null},
    {name:"Sean Murphy",       pos:"C", hand:"R",ev:91.5,la:16.0,barrel:13.5,iso:.268,hrfb:18,hh:47,seasonHR:null},
    {name:"Ozzie Albies",      pos:"2B",hand:"S",ev:90.5,la:14.0,barrel:11.5,iso:.245,hrfb:16,hh:45,seasonHR:null},
    {name:"Orlando Arcia",     pos:"SS",hand:"R",ev:88.5,la:13.5,barrel:8.5, iso:.195,hrfb:12,hh:40,seasonHR:null},
    {name:"Whit Merrifield",   pos:"LF",hand:"R",ev:88.0,la:12.0,barrel:7.5, iso:.178,hrfb:10,hh:38,seasonHR:null},
  ],
  // ── DODGERS ──────────────────────────────────────────────────────────────
  "Dodgers":[
    {name:"Shohei Ohtani",     pos:"DH",hand:"L",ev:94.5,la:13.8,barrel:18.1,iso:.338,hrfb:26,hh:53,seasonHR:null},
    {name:"Freddie Freeman",   pos:"1B",hand:"L",ev:91.5,la:16.9,barrel:14.2,iso:.262,hrfb:18,hh:48,seasonHR:null},
    {name:"Mookie Betts",      pos:"RF",hand:"R",ev:91.8,la:16.5,barrel:14.8,iso:.278,hrfb:20,hh:49,seasonHR:null},
    {name:"Will Smith",        pos:"C", hand:"R",ev:91.0,la:16.0,barrel:13.0,iso:.262,hrfb:18,hh:46,seasonHR:null},
    {name:"Max Muncy",         pos:"3B",hand:"L",ev:92.0,la:20.0,barrel:16.0,iso:.300,hrfb:24,hh:50,seasonHR:null},
    {name:"Tommy Edman",       pos:"2B",hand:"S",ev:89.5,la:12.5,barrel:9.5, iso:.208,hrfb:13,hh:41,seasonHR:null},
    {name:"Teoscar Hernández", pos:"LF",hand:"R",ev:92.0,la:15.5,barrel:14.5,iso:.280,hrfb:21,hh:50,seasonHR:null},
    {name:"Andy Pages",        pos:"CF",hand:"R",ev:91.0,la:14.5,barrel:12.5,iso:.255,hrfb:17,hh:46,seasonHR:null},
    {name:"Miguel Rojas",      pos:"SS",hand:"R",ev:87.5,la:11.5,barrel:6.5, iso:.162,hrfb:9, hh:37,seasonHR:null},
  ],
};

// ── Main App ──────────────────────────────────────────────────────────────
export default function HRScout() {
  const [liveScores,   setLiveScores]   = useState({});
  const [scoutNotes,   setScoutNotes]   = useState({});
  const [noteLoading,  setNoteLoading]  = useState({});
  const [scoresLoaded, setScoresLoaded] = useState(false);
  const [expandedKey,  setExpandedKey]  = useState(null);
  const [activeGame,   setActiveGame]   = useState(null);
  const [openGames,    setOpenGames]    = useState(new Set());
  const [openPlayers,     setOpenPlayers]     = useState(new Set());
  const [parlaySlide,     setParlaySlide]     = useState(0);
  const [darkMode,       setDarkMode]       = useState(true);
  const [matchupAnalysis, setMatchupAnalysis] = useState({});  // gk-batting → {players,bestBet,summary,status}
  const [analysisLoading, setAnalysisLoading] = useState({});  // gk-batting → bool
  const [analyzingAll,   setAnalyzingAll]   = useState(false);
  const [analyzeProgress,setAnalyzeProgress]= useState({done:0,total:0});
  const [lineupData,   setLineupData]   = useState({});
  const [lineupLoaded, setLineupLoaded] = useState(false);
  const [lineupLoading,setLineupLoading]= useState(false);
  const [liveStats,    setLiveStats]    = useState({});
  const [statsLoaded,  setStatsLoaded]  = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);
  const [recentStats,  setRecentStats]  = useState({});   // 14-day rolling
  const [recentLoaded, setRecentLoaded] = useState(false);

  // ── Build scored sides ────────────────────────────────────────────────
  // ── Theme tokens ────────────────────────────────────────────────────────
  const T = darkMode ? {
    bg:"#060d18",bgCard:"#090f1c",bgInner:"#07101a",bgDeep:"#070f1a",bgHeader:"#07101e",
    border:"#101c2c",borderAcc:"#1a3a1a",
    text:"#ddeeff",textSub:"#8ab0c8",textMute:"#2d4060",textFaint:"#1e3040",textHdr:"#fff",
    accent:"#f5a623",green:"#81c784",blue:"#4fc3f7",purple:"#ce93d8",red:"#ef5350",
    rowHover:"rgba(245,166,35,0.04)",
  } : {
    bg:"#eef2f7",bgCard:"#ffffff",bgInner:"#f8fafc",bgDeep:"#ffffff",bgHeader:"#1e3a5f",
    border:"#d0dcea",borderAcc:"#b8d4b8",
    text:"#1a2a3a",textSub:"#3a5a7a",textMute:"#7a9ab8",textFaint:"#9ab0c8",textHdr:"#ffffff",
    accent:"#d97706",green:"#16a34a",blue:"#0284c7",purple:"#7c3aed",red:"#dc2626",
    rowHover:"rgba(217,119,6,0.06)",
  };

  // buildRoster: if confirmed lineup exists use it (correct players in batting order),
  // merge with ROSTERS for Statcast stats, fallback to full ROSTERS if lineup not posted
  const buildRoster = (teamName, pitHand, pf, park, pit) => {
    const confirmed = lineupData[teamName] || [];
    const baseRoster = ROSTERS[teamName] || [];
    let players;

    if (confirmed.length >= 4) {
      // Use confirmed lineup order — find Statcast stats for each name
      players = confirmed.map(entry => {
        // Try to match by name from ROSTERS
        const norm = s => (s||'').toLowerCase().replace(/[^a-z ]/g,"").trim();
        const found = baseRoster.find(b =>
          norm(b.name) === norm(entry.name) ||
          norm(b.name).split(" ").pop() === norm(entry.name).split(" ").pop()
        );
        if (found) return { ...found, name: entry.name, lineupSlot: entry.slot };
        // Not in ROSTERS — build minimal profile from name only
        return {
          name: entry.name, pos:"?", hand:"R",
          ev: 89.0, la: 13.0, barrel: 9.0, iso: .200, hrfb: 12, hh: 41, seasonHR: null,
          lineupSlot: entry.slot, fromLineup: true, missingStats: true,
        };
      });
    } else {
      // No confirmed lineup yet — use full roster
      players = baseRoster;
    }

    return players
      .map(b => ({
        ...b,
        score: computeScore(b, pit.hr9, pit.fb, pit.kPct, pitHand, pf, park, pit),
        hrPct: 0,
        platoon: platoonStr(b.hand, pitHand),
      }))
      .map(b => ({ ...b, hrPct: toHrPct(b.score) }))
      .sort((a, z) => z.score - a.score);
  };

  const allSides = useMemo(()=>{
    const arr = [];
    GAMES.forEach(g=>{
      const gk = `${g.away}@${g.home}`;
      const awayPit = PITCHERS[g.homeP]||{hr9:1.1,fb:38,kPct:22,era:"4.00",rec:"0-0"};
      const homePit = PITCHERS[g.awayP]||{hr9:1.1,fb:38,kPct:22,era:"4.00",rec:"0-0"};
      const awayPlayers = buildRoster(g.away, g.homeH, g.pf, g.park, awayPit);
      const homePlayers = buildRoster(g.home, g.awayH, g.pf, g.park, homePit);
      arr.push({batting:g.away,pitcher:g.homeP,pitHand:g.homeH,pit:awayPit,game:`${g.away} @ ${g.home}`,park:g.park,pf:g.pf,time:g.time,gk,players:awayPlayers,lineupConfirmed:!!(lineupData[g.away]?.length>=4)});
      arr.push({batting:g.home,pitcher:g.awayP,pitHand:g.awayH,pit:homePit,game:`${g.away} @ ${g.home}`,park:g.park,pf:g.pf,time:g.time,gk,players:homePlayers,lineupConfirmed:!!(lineupData[g.home]?.length>=4)});
    });
    return arr;
  },[lineupData]);

  const allPlayers = useMemo(()=>{
    const arr=[];
    allSides.forEach(s=>s.players.forEach(p=>arr.push({...p,batting:s.batting,pitcher:s.pitcher,pitHand:s.pitHand,game:s.game,park:s.park,pf:s.pf,gk:s.gk})));
    return arr.sort((a,b)=>b.score-a.score);
  },[allSides]);

  // ── 6 Parlays (3x 3-leg, 3x 2-leg) — zero player overlap across all ────
  const parlays = useMemo(()=>{
    if(allPlayers.length < 12) return [];

    // Build enriched player pool — merge AI analysis scores when available
    // AI-analyzed players get their real scored hrPct; unanalyzed use formula
    const enrichedPlayers = allPlayers.map(p => {
      const aKey = `${p.gk}-${p.batting}`;
      const analysis = matchupAnalysis[aKey];
      if(analysis?.status === "done" && analysis.players?.length > 0){
        const aiPlayer = analysis.players.find(ap =>
          ap.name?.toLowerCase().includes(p.name.toLowerCase().split(" ").pop()) ||
          p.name.toLowerCase().includes(ap.name?.toLowerCase().split(" ").pop() || "zzz")
        );
        if(aiPlayer){
          // Use AI score + hrPct — this is the real analyzed value
          return {
            ...p,
            score:   aiPlayer.score  ?? p.score,
            hrPct:   aiPlayer.hrPct  ?? p.hrPct,
            platoon: aiPlayer.platoon ?? p.platoon,
            aiScored: true,
          };
        }
      }
      return p; // fallback to formula
    });

    const analyzedCount = enrichedPlayers.filter(p => p.aiScored).length;
    const dataSource = analyzedCount > 0
      ? `AI-scored: ${analyzedCount} players · formula: ${enrichedPlayers.length - analyzedCount}`
      : "Formula scores — tap Analyze on any matchup for AI picks";

    const used = new Set(); // no player repeated across any parlay

    const pick = (pool, n) => {
      const usedGames = new Set();
      const picks = [];
      for(const p of pool){
        if(picks.length === n) break;
        if(used.has(p.name)) continue;
        if(usedGames.has(p.gk)) continue;
        picks.push(p);
        usedGames.add(p.gk);
      }
      return picks;
    };

    const mk = (picks, label, icon, desc, tag) => {
      picks.forEach(p => used.add(p.name));
      const prob = picks.reduce((a,b) => a*(b.hrPct||0)/100, 1);
      return { label, icon, desc, tag, picks, prob, odds: toAmOdds(prob), legs: picks.length, dataSource };
    };

    // Sort pools by AI score when available, formula score otherwise
    const sorted    = [...enrichedPlayers].sort((a,b) => b.score - a.score);
    const byScore   = sorted;
    const byPark    = sorted.filter(p => (p.pf||1) >= 1.05);
    const byPlatoon = sorted.filter(p => p.platoon === "ADV").sort((a,b) => b.hrPct - a.hrPct);
    const byVulnPit = sorted.filter(p => (PITCHERS[p.pitcher]?.hr9||1) >= 1.3);
    const byEV      = [...enrichedPlayers].filter(p => p.ev >= 92).sort((a,b) => b.ev - a.ev);
    const bySleeper = sorted.filter(p => p.score >= 45 && p.score < 65).sort((a,b) => b.hrPct - a.hrPct);

    // 3-leg parlays
    const p1 = mk(pick(byScore,   3), "Power Stack",     "🔥", "Top 3 HR threats — AI scored when analyzed",  "Highest score · one per game");
    const p2 = mk(pick(byPark,    3), "Park Monsters",   "🏟", "Best hitters in hitter-friendly parks",       "PF 1.05+ · AI scored when available");
    const p3 = mk(pick(byPlatoon, 3), "Platoon Edge",    "⚡", "Opposite-hand advantage hitters",             "Platoon ADV · unique picks");
    // 2-leg parlays
    const p4 = mk(pick(byVulnPit, 2), "Pitcher Exploit", "🎯", "Best bats vs vulnerable pitchers (HR/9≥1.3)", "Pitcher weakness angle");
    const p5 = mk(pick(byEV,      2), "Exit Velo",       "💥", "Highest raw exit velocity hitters today",     "EV 92+ mph · contact quality");
    const p6 = mk(pick(bySleeper, 2), "Sleeper Value",   "💎", "Mid-range picks with overlooked edges",       "Value angle · score 45-65");

    return [p1,p2,p3,p4,p5,p6].filter(p => p.picks.length === p.legs);
  },[allPlayers, matchupAnalysis]);

  // ── Helpers ───────────────────────────────────────────────────────────
  const loadScores = useCallback(async()=>{
    const scores = await fetchLiveScores();
    setLiveScores(scores);
    setScoresLoaded(true);
  },[]);

  const loadLineups = async()=>{
    setLineupLoading(true);
    const today = new Date().toISOString().slice(0,10);
    const data = await fetchMLBLineups(today);
    setLineupData(data);
    setLineupLoaded(true);
    setLineupLoading(false);
  };

  const loadStats = async()=>{
    setStatsLoading(true);
    const map = await fetchSeasonStats();
    setLiveStats(map);
    setStatsLoaded(Object.keys(map).length>0);
    setStatsLoading(false);
  };

  const slotBonus = (slot)=>{
    if(!slot) return 0;
    if(slot>=2&&slot<=4) return 4;
    if(slot===1||slot===5) return 2;
    if(slot===6) return 0;
    return -3;
  };

  const getLineupSlot = (teamName, playerName)=>{
    const lineup = lineupData[teamName]||[];
    const entry = lineup.find(e=>e.name&&playerName&&(
      (e.name||"").toLowerCase().includes((playerName||"").toLowerCase().split(" ").slice(-1)[0])||
      (playerName||"").toLowerCase().includes((e.name?.toLowerCase().split(" ").slice(-1)[0])||"zzz")
    ));
    return entry?.slot||null;
  };

  const loadRecent = async()=>{
    const map = await fetchRollingStats(14);
    if(Object.keys(map).length>0){ setRecentStats(map); setRecentLoaded(true); }
  };

  // Auto-fetch everything on mount: season stats + 14-day rolling + lineups
  useEffect(()=>{
    loadStats();
    loadRecent();
    loadLineups();
  },[]);

  const getStat = (playerName, field, fallback=null)=>{
    const entry = fuzzyMatch(playerName, liveStats);
    if (!entry) return fallback;
    const val = entry[field];
    return (val !== null && val !== undefined) ? val : fallback;
  };

  // getRecentStat — 14-day rolling lookup
  const getRecentStat = (playerName, field)=>{
    const entry = fuzzyMatch(playerName, recentStats);
    if(!entry) return null;
    const val = entry[field];
    return (val!==null&&val!==undefined) ? val : null;
  };

  // getEffectiveScore — applies three accuracy boosters on top of formula score:
  //  1. 14-day rolling ISO (more predictive than season)
  //  2. Confirmed lineup slot bonus/penalty
  //  3. Odds calibration (applied during AI analysis, stored in matchupAnalysis)
  const getEffectiveScore = (p, batting, baseScore)=>{
    let adj = baseScore;

    // Booster 1: 14-day rolling ISO vs season ISO
    // Recent ISO 60% weight, season 40% — hot hitters get bonus, cold get penalty
    const recentISO = getRecentStat(p.name, "iso");
    if(recentISO!==null && p.iso){
      const recentFloat = parseFloat(recentISO);
      const blended = recentFloat*0.60 + p.iso*0.40;
      const delta = (blended - p.iso) * 100; // delta in ISO points
      adj += Math.max(-8, Math.min(8, delta * 1.5)); // cap ±8 pts
    }

    // Booster 2: Confirmed lineup slot
    const slot = getLineupSlot(batting, p.name);
    if(slot!==null){
      if(slot>=2&&slot<=4) adj += 4;
      else if(slot===1||slot===5) adj += 2;
      else if(slot>=7) adj -= 3;
    } else if(lineupLoaded) {
      adj -= 2; // penalise if confirmed lineup exists but player not found
    }

    // Booster 3: Recent HR pace (rolling)
    const recentHR = getRecentStat(p.name, "hr");
    const recentAB = getRecentStat(p.name, "ab");
    if(recentHR!==null && recentAB!==null && recentAB>=10){
      const recentRate = recentHR / recentAB;
      if(recentRate > 0.07) adj += 4;       // >1 HR per 14 AB in last 2 weeks
      else if(recentRate > 0.04) adj += 2;  // steady pace
      else if(recentAB>=15&&recentHR===0) adj -= 3; // cold — no HRs in decent sample
    }

    return Math.max(0, Math.min(100, Math.round(adj)));
  };

  const togglePlayer = (key)=>setOpenPlayers(prev=>{
    const next=new Set(prev);
    next.has(key)?next.delete(key):next.add(key);
    return next;
  });

  const getLive = (g)=>{
    const key=`${g.away} @ ${g.home}`;
    const key2=`${g.away}@${g.home}`;
    return liveScores[key]||liveScores[key2]||null;
  };

  const analyzeMatchup = useCallback(async(side)=>{
    const key = `${side.gk}-${side.batting}`;
    setAnalysisLoading(prev=>({...prev,[key]:true}));
    setMatchupAnalysis(prev=>({...prev,[key]:{status:"loading",players:[],bestBet:"",summary:""}}));

    const pit = PITCHERS[side.pitcher]||{};
    const dims = PARK_DIMS[side.park]||{};
    const ex = side.players.map(p=>{
      const live    = getStat(p.name,"hr",null);
      const extras  = PLAYER_EXTRAS[p.name]||{};
      const recent  = fuzzyMatch(p.name,recentStats)||{};
      const slot    = getLineupSlot(side.batting,p.name);
      const effS    = getEffectiveScore(p,side.batting,p.score);
      const recentLine = recent.ab>=5
        ? ` | 14d:HR=${recent.hr||0}/${recent.ab}AB SLG=${recent.slg||"?"} ISO=${recent.iso||"?"}`
        : " | 14d:no data";
      const slotLine = slot ? ` | Slot#${slot}(${slot<=4?"heart of order":slot<=6?"mid":"lower"})` : lineupLoaded?" | NOT in lineup":"";
      return `• ${p.name} (${p.pos},${p.hand}) ModelScore:${effS}/100 EV:${p.ev} LA:${p.la}° Barrel:${p.barrel}% HR/FB:${p.hrfb}% ISO:.${Math.round(p.iso*1000)}${extras.pull?` Pull:${extras.pull}%`:""}${extras.xHR?` xHR:${extras.xHR}`:""}${live!=null?` Season HRs:${live}✓`:""} ${recentLine}${slotLine}`;
    }).join("\n");

    const prompt = `You are an elite MLB HR analyst. Score every batter in this matchup for HR probability TODAY using web search for real 2026 data.

MATCHUP: ${side.batting} batting vs ${side.pitcher} (${side.pitHand}HP) at ${side.park}
Park Factor: ${side.pf} | ${dims.note||"standard park"} | LF:${dims.lf||"?"}ft CF:${dims.cf||"?"}ft RF:${dims.rf||"?"}ft
Pitcher: ${pit.era} ERA ${pit.rec} | HR/9:${pit.hr9} FB%:${pit.fb}% HR/FB%:${pit.hrFb||"?"}% K%:${pit.kPct}% Zone%:${pit.zone||"?"}% Velo:${pit.velo||"?"}mph | ${pit.note||""}

BATTERS (baseline Statcast metrics provided):
${ex}

━━ RUN THESE SEARCHES NOW: ━━
1. "${side.pitcher} 2026 stats recent starts ERA" — pitcher current form, velocity trend
2. "${side.batting} home runs 2026 stats lineup" — team power numbers this season  
3. "${side.players.slice(0,3).map(p=>p.name).join(", ")} 2026 barrel rate exit velocity Statcast" — top batter real current metrics
4. "home plate umpire ${side.game} May 8 2026" — today's umpire and zone tendency
5. "${side.players[0]?.name||""} ${side.pitcher} home run prop odds May 2026" — market HR odds

━━ SCORING FACTORS (weight each one): ━━
LAUNCH: EV 95+ elite (14pts), LA 25-35° HR zone (9pts), Barrel% (7pts)
POWER: ISO/HR-FB/Hard-Hit% (15pts combined), Pull%×park wall match (4pts)  
PITCHER: HR/9 rate (8pts), HR/FB% allowed (4pts), K% penalty, Zone% bonus
PARK: Factor ${side.pf} (7pts), ${side.pf>=1.10?"hitter-friendly — boost all scores":side.pf<=0.92?"pitcher-friendly — reduce all scores":"neutral"}
PLATOON: Opposite hand = ADV +6pts, same hand = DIS -3pts, switch = neutral
FORM: Anything found in searches about recent hot/cold streaks
MARKET: If odds found, they override model when they differ >8 pts

RULES:
- Cannot HR: ISO<.170 vs non-vulnerable pitcher | K%>30 AND batter FB%<32 | not in confirmed lineup
- Must boost: EV>95 + platoon ADV + park PF>1.05 + pitcher HR/9>1.3
- LINEUP SLOT: Slots 2-4 get +4 pts (more PA + RBI situations). Slots 7-9 get -3 pts. Not in lineup = 0% HR
- 14-DAY FORM: If recent 14d stats show player hit 3+ HRs in last 14 days = hot, add 6 pts. Zero HRs in 20+ AB = cold, subtract 4 pts
- ODDS CALIBRATION (most important rule): If market HR odds found, convert to implied probability. If market >8% higher than your score would imply, RAISE score. Market has lineup confirmation, injury info, sharp money — always defer to market when it disagrees strongly
- Score 0-100 where 50 = average MLB HR probability for this specific game context

Return ONLY valid JSON. CRITICAL: never use apostrophes or quotes inside string values — replace with spaces or omit. No markdown fences. No trailing commas.
{"players":[{"name":"Full Name","score":72,"hrPct":18,"platoon":"ADV","topFactor":"Elite EV and platoon edge","redFlag":"High K rate limits opportunities","confidence":"high","liveEV":94.5,"liveBarrel":14},{"name":"Next Player","score":65,"hrPct":15,"platoon":"NEU","topFactor":"Good barrel rate","redFlag":"Pitcher keeps ball down","confidence":"medium","liveEV":91.0,"liveBarrel":11}],"bestBet":"Name — reason without apostrophes","summary":"Two sentences no special chars","umpire":"Name — zone tendency","pitcherTrend":"sharp or struggling — cite stat","weather":"temp and wind"}

Sort players by score descending. Be precise — spread scores realistically.`;

    // ── Robust JSON extractor ────────────────────────────────────────────
    const extractJSON = (str) => {
      if(!str) return null;
      str = str.replace(/```json|```/g,"").trim();
      const pIdx = str.indexOf('"players"');
      const start = str.lastIndexOf("{", pIdx > -1 ? pIdx : undefined);
      const end   = str.lastIndexOf("}");
      if(start === -1 || end <= start) return null;
      let j = str.slice(start, end + 1);
      j = j.replace(/[\x00-\x1F\x7F]/g, " ").replace(/,\s*([}\]])/g, "$1");
      try { return JSON.parse(j); } catch(_){}
      try { return Function('"use strict";return (' + j + ')')(); } catch(_){}
      const m = j.match(/"players"\s*:\s*(\[[\s\S]*?\])/);
      if(m) { try { return { players: JSON.parse(m[1]) }; } catch(_){} }
      return null;
    };

    const extractText = (blocks) =>
      (blocks||[]).filter(b=>b.type==="text").map(b=>b.text||"").join("\n");

    const callAPI = async (msgs, useSearch, maxTok) => {
      const body = { model:"claude-sonnet-4-20250514", max_tokens:maxTok||2000, messages:msgs };
      if(useSearch) body.tools = [{type:"web_search_20250305",name:"web_search"}];
      const res = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",
        headers:{"Content-Type":"application/json","x-api-key":ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01","anthropic-dangerous-direct-browser-access":"true"},
        body:JSON.stringify(body)
      });
      if(res.status===429) throw new Error("Rate limited — wait 30s and retry");
      if(res.status===529) throw new Error("API overloaded — wait 60s and retry");
      const data = await res.json();
      if(data.error) throw new Error(data.error.message||data.error.type||"API error");
      return data;
    };

    try {
      // Attempt 1: full analysis with web search
      const data1 = await callAPI([{role:"user",content:prompt}], true, 2000);
      const text1 = extractText(data1.content);
      const parsed1 = extractJSON(text1);
      if(parsed1?.players?.length > 0){
        setMatchupAnalysis(prev=>({...prev,[key]:{
          status:"done", players:parsed1.players,
          bestBet:parsed1.bestBet||"", summary:parsed1.summary||"",
          umpire:parsed1.umpire||"", pitcherTrend:parsed1.pitcherTrend||"", weather:parsed1.weather||"",
        }}));
        setAnalysisLoading(prev=>({...prev,[key]:false}));
        return;
      }

      // Attempt 2: simplified prompt, no web search
      const pit2 = PITCHERS[side.pitcher]||{};
      const simplePmt = "Score these batters for HR probability TODAY vs "+side.pitcher+" ("+side.pitHand+"HP, ERA "+pit2.era+", HR/9 "+pit2.hr9+", K% "+pit2.kPct+"%) at "+side.park+" (PF "+side.pf+").\n\nBatters:\n"+side.players.map(p=>p.name+" ("+p.hand+"HH, EV:"+p.ev+", Barrel:"+p.barrel+"%, ISO:."+Math.round(p.iso*1000)+", platoon:"+p.platoon+")").join("\n")+"\n\nReturn ONLY valid JSON no prose no markdown no apostrophes:\n{\"players\":[{\"name\":\"Full Name\",\"score\":72,\"hrPct\":18,\"platoon\":\"ADV\",\"topFactor\":\"reason\",\"redFlag\":\"concern\",\"confidence\":\"high\"}],\"bestBet\":\"Name reason\",\"summary\":\"Two sentences\"}";
      const data2 = await callAPI([{role:"user",content:simplePmt}], false, 1400);
      const text2 = extractText(data2.content);
      const parsed2 = extractJSON(text2);
      if(parsed2?.players?.length > 0){
        setMatchupAnalysis(prev=>({...prev,[key]:{
          status:"done", players:parsed2.players,
          bestBet:parsed2.bestBet||"", summary:(parsed2.summary||"")+" (simplified mode)",
          umpire:"", pitcherTrend:"", weather:"",
        }}));
      } else {
        throw new Error("Both attempts returned no valid player data");
      }
    } catch(e){
      const msg = e.message||"Unknown error";
      const isRate = msg.includes("Rate")||msg.includes("overload")||msg.includes("429");
      setMatchupAnalysis(prev=>({...prev,[key]:{
        status:"error", players:[], bestBet:"", summary:
          isRate?"Rate limited — wait 30s then tap Analyze again":"Failed: "+msg+" — tap Analyze to retry"
      }}));
    }
    setAnalysisLoading(prev=>({...prev,[key]:false}));
  },[liveStats,lineupData,recentStats]);



  const analyzeAll = useCallback(async()=>{
    if(analyzingAll) return;
    setAnalyzingAll(true);
    // Build all sides from current GAMES
    const sides = [];
    GAMES.forEach(g=>{
      const gk=`${g.away}@${g.home}`;
      const awayPit=PITCHERS[g.homeP]||{hr9:1.1,fb:38,kPct:22,era:"4.00",rec:"0-0"};
      const homePit=PITCHERS[g.awayP]||{hr9:1.1,fb:38,kPct:22,era:"4.00",rec:"0-0"};
      const awayRoster=buildRoster(g.away,g.homeH,g.pf,g.park,awayPit);
      const homeRoster=buildRoster(g.home,g.awayH,g.pf,g.park,homePit);
      sides.push({batting:g.away,pitcher:g.homeP,pitHand:g.homeH,pit:awayPit,game:`${g.away} @ ${g.home}`,park:g.park,pf:g.pf,time:g.time,gk,players:awayRoster,lineupConfirmed:!!(lineupData[g.away]?.length>=4)});
      sides.push({batting:g.home,pitcher:g.awayP,pitHand:g.awayH,pit:homePit,game:`${g.away} @ ${g.home}`,park:g.park,pf:g.pf,time:g.time,gk,players:homeRoster,lineupConfirmed:!!(lineupData[g.home]?.length>=4)});
    });
    setAnalyzeProgress({done:0,total:sides.length});
    for(let i=0;i<sides.length;i++){
      await analyzeMatchup(sides[i]);
      setAnalyzeProgress({done:i+1,total:sides.length});
      if(i<sides.length-1) await new Promise(r=>setTimeout(r,1500));
    }
    setAnalyzingAll(false);
  },[analyzeMatchup,lineupData,analyzingAll]);

  const loadScoutNote = useCallback(async(side)=>{
    const key=`${side.gk}-${side.batting}`;
    setNoteLoading(prev=>({...prev,[key]:true}));
    const top5 = side.players.slice(0,5).map(p=>{
      const live = fuzzyMatch(p.name,liveStats);
      return {...p, lineupSlot:getLineupSlot(side.batting,p.name), liveHR:live?.hr??null, liveAVG:live?.avg??null, liveSLG:live?.slg??null };
    });
    const note = await getScoutNote(side.batting,side.pitcher,side.pitHand,side.park,side.pf,top5,side.game);
    setScoutNotes(prev=>({...prev,[key]:note}));
    setNoteLoading(prev=>({...prev,[key]:false}));
  },[lineupData,liveStats]);

  const renderNote = (note)=>{
    if(!note)return null;
    return note.split("\n").filter(Boolean).map((line,i)=>{
      const isBestBet  = line.startsWith("BEST BET");
      const isUmpire   = line.startsWith("UMPIRE:");
      const isOdds     = line.startsWith("ODDS SIGNAL:");
      const isPitTrend = line.startsWith("PITCHER TREND:");
      const isWeather  = line.startsWith("WEATHER:");
      const isNumbered = /^[1-9]\./.test(line);
      const color = isBestBet?"#f5a623":isUmpire?"#ce93d8":isOdds?"#4fc3f7":isPitTrend?"#81c784":isWeather?"#8ab8c8":isNumbered?"#b8cce0":"#8ab0c8";
      const bg    = isBestBet?"rgba(245,166,35,0.08)":isUmpire?"rgba(206,147,216,0.06)":isOdds?"rgba(79,195,247,0.06)":isPitTrend?"rgba(129,199,132,0.06)":isWeather?"rgba(79,150,200,0.06)":"transparent";
      return(
        <div key={i} style={{fontSize:isBestBet?11:10,color,lineHeight:1.65,marginBottom:4,fontFamily:"monospace",fontWeight:isBestBet?700:400,background:bg,padding:bg!=="transparent"?"4px 7px":"0",borderRadius:bg!=="transparent"?5:0}}>
          {line}
        </div>
      );
    });
  };

  const displaySides = activeGame ? allSides.filter(s=>s.gk===activeGame) : allSides;

  // ── JSX ───────────────────────────────────────────────────────────────
  return (
    <div style={{minHeight:"100vh",background:T.bg,fontFamily:"Georgia,serif",color:T.text}}>

      {/* Header */}
      <div style={{background:T.bgHeader,borderBottom:`1px solid ${T.border}`,padding:"11px 16px",position:"sticky",top:0,zIndex:10}}>
        <div style={{display:"flex",alignItems:"center",gap:10,maxWidth:760,margin:"0 auto"}}>
          <div style={{width:28,height:28,borderRadius:"50%",background:"linear-gradient(135deg,#f5a623,#c44800)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:13}}>⚾</div>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:700,color:"#fff"}}>HR Scout <span style={{fontSize:9,color:"rgba(255,255,255,0.45)",fontFamily:"monospace"}}>MLB · May 9</span></div>
            <div style={{fontSize:8,color:"rgba(255,255,255,0.5)",letterSpacing:1.5,textTransform:"uppercase",fontFamily:"monospace"}}>9-Factor Model · 2026 Stats · {GAMES.length} Games</div>
          </div>

          {/* ── Dark / Light toggle ── */}
          <button onClick={()=>setDarkMode(d=>!d)} aria-label="Toggle theme"
            style={{display:"flex",alignItems:"center",gap:6,padding:"5px 10px",borderRadius:20,border:"1px solid rgba(255,255,255,0.2)",background:"rgba(255,255,255,0.08)",cursor:"pointer",flexShrink:0,transition:"all 0.2s"}}>
            <span style={{fontSize:13,lineHeight:1}}>{darkMode?"🌙":"☀️"}</span>
            <div style={{width:34,height:19,borderRadius:10,background:darkMode?"#1e3a5a":"#d0e4f4",position:"relative",transition:"background 0.25s",flexShrink:0}}>
              <div style={{width:15,height:15,borderRadius:"50%",background:darkMode?"#4fc3f7":"#1e3a5f",position:"absolute",top:2,left:darkMode?17:2,transition:"left 0.25s",boxShadow:"0 1px 4px rgba(0,0,0,0.4)"}}/>
            </div>
          </button>

        </div>
      </div>

      <div style={{maxWidth:760,margin:"0 auto",padding:"12px 12px 40px"}}>

        {/* ── GAME GRID ── */}
        <div style={{background:T.bgCard,border:`1px solid ${T.border}`,borderRadius:10,padding:"12px 14px",marginBottom:12}}>
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8}}>
            <div style={{width:2,height:11,background:"#f5a623",borderRadius:2}}/>
            <span style={{fontSize:9,color:"#f5a623",fontFamily:"monospace",letterSpacing:2,textTransform:"uppercase"}}>May 7 Slate — {GAMES.length} Games</span>
            <span style={{marginLeft:"auto",fontSize:8,color:"#1e3040",fontFamily:"monospace"}}>tap to filter</span>
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:4}}>
            {GAMES.map((g,i)=>{
              const ls=getLive(g);
              const gk=`${g.away}@${g.home}`;
              const isActive=activeGame===gk;
              const awayHRs=ls?.awayHRs||[];
              const homeHRs=ls?.homeHRs||[];
              const hasHR=awayHRs.length>0||homeHRs.length>0;
              return(
                <div key={i} style={{borderRadius:8,border:`1px solid ${isActive?"#f5a623":"#101c2c"}`,background:isActive?"rgba(245,166,35,0.04)":T.bgInner,overflow:"hidden"}}>
                  <button onClick={()=>setActiveGame(isActive?null:gk)}
                    style={{width:"100%",padding:"8px 11px",border:"none",background:"transparent",cursor:"pointer",textAlign:"left",display:"flex",alignItems:"center",gap:10}}>
                    <div style={{flex:1}}>
                      <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
                        <span style={{fontSize:11,color:"#c0d8f0",fontWeight:600}}>{g.away} <span style={{color:"#2a4060",fontSize:9}}>@</span> {g.home}</span>
                        <span style={{fontSize:8,color:"#2d4060",fontFamily:"monospace"}}>{g.time}</span>
                        <span style={{fontSize:8,color:pfCol(g.pf),fontFamily:"monospace"}}>PF {g.pf}</span>
                      </div>
                      <div style={{fontSize:8,color:"#2a4060",fontFamily:"monospace",marginTop:2}}>
                        <span style={{color:eCol(PITCHERS[g.awayP]?.era||"4.00")}}>{g.awayP} {PITCHERS[g.awayP]?.era}</span>
                        <span style={{color:"#1e3040"}}> vs </span>
                        <span style={{color:eCol(PITCHERS[g.homeP]?.era||"4.00")}}>{g.homeP} {PITCHERS[g.homeP]?.era}</span>
                      </div>
                    </div>
                    {ls&&ls.status!=="scheduled"&&(
                      <div style={{textAlign:"center",fontFamily:"monospace",flexShrink:0}}>
                        <div style={{fontSize:15,color:"#ddeeff",fontWeight:700}}>{ls.awayScore??0}–{ls.homeScore??0}</div>
                        <div style={{fontSize:8,color:ls.status==="final"?"#81c784":"#f5a623"}}>{ls.status==="final"?"FINAL":"LIVE"}</div>
                      </div>
                    )}
                  </button>
                  {hasHR&&(
                    <div style={{borderTop:"1px solid #101c2c",padding:"5px 11px",display:"flex",gap:6,flexWrap:"wrap",background:"#060c11"}}>
                      <span style={{fontSize:8,color:"#f5a623",fontFamily:"monospace",fontWeight:700}}>⚾</span>
                      {awayHRs.map((h,j)=><span key={`a${j}`} style={{fontSize:9,color:"#f5a623",fontFamily:"monospace",background:"rgba(245,166,35,0.12)",padding:"2px 7px",borderRadius:4}}>{g.away}: {h}</span>)}
                      {homeHRs.map((h,j)=><span key={`h${j}`} style={{fontSize:9,color:"#81c784",fontFamily:"monospace",background:"rgba(129,199,132,0.12)",padding:"2px 7px",borderRadius:4}}>{g.home}: {h}</span>)}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          {activeGame&&<div style={{marginTop:7,fontSize:9,color:"#f5a623",fontFamily:"monospace",textAlign:"center"}}>Showing: {activeGame.replace("@"," @ ")} · Tap again to clear</div>}
          {lineupLoaded&&Object.keys(lineupData).length>0&&(
            <div style={{marginTop:6,padding:"6px 12px",background:"rgba(129,199,132,0.07)",border:"1px solid #1a3a1a",borderRadius:7,display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
              <span style={{fontSize:9,color:"#81c784",fontFamily:"monospace",fontWeight:700}}>✓ LINEUPS LOADED</span>
              {Object.keys(lineupData).slice(0,6).map(t=>(
                <span key={t} style={{fontSize:8,color:"#3a6040",fontFamily:"monospace"}}>{t} ({lineupData[t]?.length||0})</span>
              ))}
            </div>
          )}
        </div>

        {/* ── ANALYZE ALL BUTTON ── */}
        <button onClick={analyzeAll} disabled={analyzingAll}
          style={{width:"100%",padding:"14px 0",borderRadius:10,border:"none",marginBottom:12,cursor:analyzingAll?"not-allowed":"pointer",fontFamily:"monospace",fontWeight:800,fontSize:13,letterSpacing:1.2,textTransform:"uppercase",transition:"all 0.2s",
            background:analyzingAll?"#0b1625":"linear-gradient(135deg,#f5a623,#c44800)",
            color:analyzingAll?"#1e3a50":"#000",
            boxShadow:analyzingAll?"none":"0 4px 20px rgba(245,166,35,0.28)"}}>
          {analyzingAll
            ?`⚙  Analyzing ${analyzeProgress.done} / ${analyzeProgress.total} matchups...`
            :Object.values(matchupAnalysis).some(a=>a.status==="done")
              ?"🔄  Re-Analyze All Matchups"
              :"🔍  Analyze All — Real Stats + Odds + Umpire"}
        </button>
        {analyzingAll&&(
          <div style={{marginBottom:12,background:T.bgCard,border:`1px solid ${T.borderAcc}`,borderRadius:10,padding:"10px 14px"}}>
            <div style={{height:4,background:"#0d1828",borderRadius:2,overflow:"hidden",marginBottom:8}}>
              <div style={{width:`${analyzeProgress.total>0?(analyzeProgress.done/analyzeProgress.total)*100:0}%`,height:"100%",background:"linear-gradient(90deg,#f5a623,#81c784)",borderRadius:2,transition:"width 0.5s ease"}}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:3}}>
              {GAMES.map((g,gi)=>{
                const gk=`${g.away}@${g.home}`;
                const awayDone=matchupAnalysis[`${gk}-${g.away}`]?.status==="done";
                const homeDone=matchupAnalysis[`${gk}-${g.home}`]?.status==="done";
                const bothDone=awayDone&&homeDone;
                return(
                  <div key={gi} style={{display:"flex",alignItems:"center",gap:5}}>
                    {bothDone
                      ?<span style={{fontSize:9,color:"#81c784",fontFamily:"monospace"}}>✓</span>
                      :awayDone||homeDone
                        ?<svg width={9} height={9} viewBox="0 0 9 9" style={{display:"inline-block",verticalAlign:"middle",flexShrink:0}}>
                           <circle cx={4.5} cy={4.5} r={3.5} fill="none" stroke="#2d4060" strokeWidth={1.2}/>
                           <path d="M 4.5 1 A 3.5 3.5 0 0 1 4.5 8" fill="#f5a623"/>
                         </svg>
                        :<span style={{fontSize:9,color:"#2d4060",fontFamily:"monospace"}}>○</span>
                    }
                    <span style={{fontSize:8,color:bothDone?"#4a6040":awayDone||homeDone?"#6a5020":"#1e3040",fontFamily:"monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                      {g.away} @ {g.home}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── PARLAYS ── */}
        {parlays.length>0&&(
          <div style={{marginBottom:14}}>
            <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:9}}>
              <div style={{width:2,height:12,background:"#ce93d8",borderRadius:2}}/>
              <span style={{fontSize:9,color:"#ce93d8",fontFamily:"monospace",letterSpacing:2.5,textTransform:"uppercase"}}>HR Parlays</span>
              <span style={{marginLeft:"auto",fontSize:8,color:"#2d4060",fontFamily:"monospace"}}>swipe or tap dots</span>
            </div>
            <div style={{overflow:"hidden",borderRadius:10}}
              onTouchStart={e=>{window._ptx=e.touches[0].clientX;}}
              onTouchEnd={e=>{const dx=window._ptx-e.changedTouches[0].clientX;if(Math.abs(dx)>40)setParlaySlide(s=>Math.max(0,Math.min(parlays.length-1,s+(dx>0?1:-1))));}} >
              <div style={{display:"flex",transition:"transform 0.35s cubic-bezier(.4,0,.2,1)",transform:"translateX(-"+(parlaySlide*100)+"%)"}}>
                {parlays.map((p,pi)=>(
                  <div key={pi} style={{minWidth:"100%",background:T.bgCard,border:`1px solid ${T.border}`,borderRadius:10,padding:"14px 16px"}}>
                    <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:11}}>
                      <div>
                        <div style={{fontSize:15,fontWeight:700,color:"#ddeeff",marginBottom:3}}>{p.icon} {p.label} <span style={{fontSize:9,color:"#2d4060",fontFamily:"monospace"}}>({p.legs}-leg)</span></div>
                        <div style={{fontSize:9,color:"#3a5070",fontFamily:"monospace"}}>{p.desc}</div>
                        <div style={{fontSize:8,color:p.picks.some(pk=>pk.aiScored)?"#81c784":"#2d4060",fontFamily:"monospace",marginTop:3}}>
                          {p.picks.some(pk=>pk.aiScored)?"✓ Uses AI analysis scores":"⚠ Formula scores — run Analyze for AI picks"}
                        </div>
                      </div>
                      <div style={{textAlign:"right",flexShrink:0}}>
                        <div style={{fontSize:15,color:"#ce93d8",fontFamily:"monospace",fontWeight:800}}>{p.odds}</div>
                        <div style={{fontSize:8,color:"#2a3a50",fontFamily:"monospace"}}>{(p.prob*100).toFixed(2)}%</div>
                      </div>
                    </div>
                    {p.picks.map((pick,i)=>(
                      <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 0",borderBottom:i<p.picks.length-1?"1px solid #101c2c":"none"}}>
                        <div style={{width:24,height:24,borderRadius:"50%",background:sCol(pick.score)+"18",border:"1px solid "+sCol(pick.score),display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,color:sCol(pick.score),flexShrink:0}}>{i+1}</div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{display:"flex",alignItems:"center",gap:5}}>
                            <div style={{fontSize:12,color:"#ddeeff",fontWeight:600,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{pick.name}</div>
                            {pick.aiScored&&<span style={{fontSize:7,color:"#81c784",fontFamily:"monospace",background:"rgba(129,199,132,0.15)",padding:"1px 5px",borderRadius:3,flexShrink:0}}>AI</span>}
                          </div>
                          <div style={{fontSize:8,color:"#2d4060",fontFamily:"monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{pick.batting} vs {pick.pitcher} · {pick.park}</div>
                          <div style={{fontSize:8,color:"#1e3040",fontFamily:"monospace"}}>{pick.platoon==="ADV"?"✅ Platoon ADV":pick.platoon==="DIS"?"⚠️ Same-hand":"⚖️ Switch"} · EV {pick.ev}mph · Barrel {pick.barrel}%</div>
                        </div>
                        <div style={{textAlign:"right",flexShrink:0}}>
                          <div style={{fontSize:15,color:sCol(pick.score),fontFamily:"monospace",fontWeight:800}}>{pick.hrPct}%</div>
                          <div style={{fontSize:7,color:"#1e3040",fontFamily:"monospace"}}>per game</div>
                        </div>
                      </div>
                    ))}
                    <div style={{marginTop:11,padding:"7px 11px",background:T.bgDeep,borderRadius:7,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div>
                        <div style={{fontSize:8,color:"#2d4060",fontFamily:"monospace",marginBottom:1}}>COMBINED</div>
                        <div style={{fontSize:12,color:"#ce93d8",fontFamily:"monospace",fontWeight:700}}>{p.odds} · {(p.prob*100).toFixed(2)}%</div>
                      </div>
                      <div style={{fontSize:8,color:"#1e3040",fontFamily:"monospace",textAlign:"right"}}>
                        {p.picks.map(pk=>pk.hrPct+"%").join(" x ")}
                        <div style={{fontSize:7,color:"#1a2a3a",marginTop:2}}>{p.tag}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:10,marginTop:9}}>
              <button onClick={()=>setParlaySlide(s=>Math.max(0,s-1))} disabled={parlaySlide===0}
                style={{width:26,height:26,borderRadius:"50%",border:"1px solid",borderColor:parlaySlide===0?"#101c2c":"#3a5570",background:"transparent",color:parlaySlide===0?"#1e3040":"#8a9bb8",cursor:parlaySlide===0?"default":"pointer",fontSize:15}}>&#8249;</button>
              <div style={{display:"flex",gap:5}}>
                {parlays.map((_,i)=>(
                  <button key={i} onClick={()=>setParlaySlide(i)}
                    style={{width:i===parlaySlide?20:8,height:8,borderRadius:4,border:"none",cursor:"pointer",background:i===parlaySlide?"#ce93d8":"#1e2e40",transition:"all 0.2s"}}/>
                ))}
              </div>
              <button onClick={()=>setParlaySlide(s=>Math.min(parlays.length-1,s+1))} disabled={parlaySlide===parlays.length-1}
                style={{width:26,height:26,borderRadius:"50%",border:"1px solid",borderColor:parlaySlide===parlays.length-1?"#101c2c":"#3a5570",background:"transparent",color:parlaySlide===parlays.length-1?"#1e3040":"#8a9bb8",cursor:parlaySlide===parlays.length-1?"default":"pointer",fontSize:15}}>&#8250;</button>
            </div>
          </div>
        )}

        {/* ── GAME DROPDOWNS ── */}
        <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:9}}>
          <div style={{width:2,height:12,background:"#81c784",borderRadius:2}}/>
          <span style={{fontSize:9,color:"#81c784",fontFamily:"monospace",letterSpacing:2,textTransform:"uppercase"}}>
            {activeGame?`${activeGame.replace("@"," @ ")} Matchups`:`All ${GAMES.length} Games`}
          </span>
          <span style={{marginLeft:"auto",fontSize:8,color:"#1e3040",fontFamily:"monospace"}}>tap game → side → player</span>
        </div>

        {(activeGame?GAMES.filter(g=>`${g.away}@${g.home}`===activeGame):GAMES).map((g,gi)=>{
          const gk=`${g.away}@${g.home}`;
          const isGameOpen=openGames.has(gk);
          const gameSides=allSides.filter(s=>s.gk===gk);
          const topPlayer=[...allPlayers].filter(p=>p.gk===gk).sort((a,b)=>b.score-a.score)[0];

          return(
            <div key={gi} style={{marginBottom:6,borderRadius:11,border:`1px solid ${isGameOpen?"#1e4a2a":"#101c2c"}`,overflow:"hidden"}}>

              {/* Level 1: Game header */}
              <button onClick={()=>setOpenGames(prev=>{const n=new Set(prev);n.has(gk)?n.delete(gk):n.add(gk);return n;})}
                style={{width:"100%",padding:"11px 14px",border:"none",background:isGameOpen?T.bgInner:T.bg,cursor:"pointer",textAlign:"left",display:"flex",alignItems:"center",gap:10}}>
                <span style={{fontSize:10,color:isGameOpen?"#81c784":"#2d4a60",flexShrink:0,transition:"transform 0.2s",display:"inline-block",transform:isGameOpen?"rotate(90deg)":"rotate(0deg)"}}>▶</span>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
                    <span style={{fontSize:13,color:T.text,fontWeight:700}}>{g.away} <span style={{color:"#2a4060",fontSize:10}}>@</span> {g.home}</span>
                    <span style={{fontSize:8,color:"#2d4060",fontFamily:"monospace"}}>{g.time}</span>
                    <span style={{fontSize:8,color:pfCol(g.pf),fontFamily:"monospace"}}>PF {g.pf}</span>
                  </div>
                  <div style={{fontSize:8,color:"#2a4060",fontFamily:"monospace",marginTop:2}}>
                    <span style={{color:eCol(PITCHERS[g.awayP]?.era||"4.00")}}>{g.awayP} {PITCHERS[g.awayP]?.era}</span>
                    <span style={{color:"#1e3040"}}> · </span>
                    <span style={{color:eCol(PITCHERS[g.homeP]?.era||"4.00")}}>{g.homeP} {PITCHERS[g.homeP]?.era}</span>
                  </div>
                </div>
                {topPlayer&&(
                  <div style={{textAlign:"right",flexShrink:0}}>
                    <div style={{fontSize:10,color:sCol(topPlayer.score),fontFamily:"monospace",fontWeight:700}}>{topPlayer.name.split(" ").slice(-1)[0]}</div>
                    <div style={{fontSize:11,color:sCol(topPlayer.score),fontFamily:"monospace",fontWeight:700}}>{topPlayer.hrPct}% {tier(topPlayer.score)}</div>
                  </div>
                )}
              </button>

              {isGameOpen&&(
                <div style={{borderTop:"1px solid #101c2c"}}>
                  {gameSides.map((side,si)=>{
                    const noteKey=`${side.gk}-${side.batting}`;
                    const dropKey=`drop-${noteKey}`;
                    const isSideOpen=expandedKey===dropKey;
                    const top1=side.players[0];

                    const aKey=`${side.gk}-${side.batting}`;
                    const analysis=matchupAnalysis[aKey]||{status:"idle",players:[],bestBet:"",summary:"",umpire:"",pitcherTrend:"",weather:""};
                    const aLoad=analysisLoading[aKey]||false;
                    const analyzed=analysis.status==="done"&&analysis.players.length>0;
                    const displayPlayers=analyzed
                      ?side.players.map(p=>{
                          const found=analysis.players.find(ap=>
                            ap.name?.toLowerCase().includes(p.name.toLowerCase().split(" ").pop())||
                            p.name.toLowerCase().includes(ap.name?.toLowerCase().split(" ").pop()||"zzz")
                          );
                          return found?{...p,...found,aiScored:true}:{...p,aiScored:false};
                        }).sort((a,b)=>b.score-a.score)
                      :side.players;

                    return(
                      <div key={si} style={{borderBottom:si===0?"1px solid #101c2c":"none"}}>
                        {/* Level 2: Side header */}
                        <button onClick={()=>setExpandedKey(isSideOpen?null:dropKey)}
                          style={{width:"100%",padding:"9px 18px",border:"none",background:isSideOpen?T.bgCard:T.bgInner,cursor:"pointer",textAlign:"left",display:"flex",alignItems:"center",gap:9}}>
                          <span style={{fontSize:9,color:isSideOpen?"#4fc3f7":"#2d4a60",flexShrink:0,display:"inline-block",transform:isSideOpen?"rotate(90deg)":"rotate(0deg)",transition:"transform 0.2s"}}>▶</span>
                          <div style={{flex:1,minWidth:0}}>
                            <div style={{display:"flex",alignItems:"center",gap:7,flexWrap:"wrap"}}>
                              <span style={{fontSize:11,color:"#b8d8f0",fontWeight:600}}>{side.batting}</span>
                              {side.lineupConfirmed
                                ?<span style={{fontSize:7,color:"#4fc3f7",fontFamily:"monospace",background:"rgba(79,195,247,0.10)",padding:"1px 5px",borderRadius:3}}>✓ lineup</span>
                                :<span style={{fontSize:7,color:"#2d4060",fontFamily:"monospace",background:"rgba(45,64,96,0.20)",padding:"1px 5px",borderRadius:3}}>projected</span>}
                              <span style={{fontSize:8,color:"#2a4060"}}>vs</span>
                              <span style={{fontSize:11,color:"#ddeeff",fontWeight:600}}>{side.pitcher}</span>
                              <span style={{fontSize:8,color:"#2d4060",fontFamily:"monospace"}}>({side.pitHand}HP)</span>
                              <span style={{fontSize:8,color:eCol(side.pit.era),fontFamily:"monospace"}}>{side.pit.era} ERA</span>
                              <span style={{fontSize:8,color:"#1e3040",fontFamily:"monospace"}}>K%:{side.pit.kPct}%</span>
                            </div>
                            <div style={{fontSize:8,color:"#2d4060",fontFamily:"monospace",marginTop:1}}>
                              HR/9:{side.pit.hr9} · FB:{side.pit.fb}% · {side.players.length} batters
                            </div>
                          </div>
                          {top1&&(
                            <div style={{textAlign:"right",flexShrink:0}}>
                              <div style={{fontSize:10,color:sCol(top1.score),fontFamily:"monospace",fontWeight:700}}>{top1.name.split(" ").slice(-1)[0]}</div>
                              <div style={{fontSize:11,color:sCol(top1.score),fontFamily:"monospace",fontWeight:700}}>{top1.hrPct}% {tier(top1.score)}</div>
                            </div>
                          )}
                        </button>

                        {isSideOpen&&(
                          <div style={{background:T.bg,borderTop:`1px solid ${T.border}`}}>
                            {/* Analyze button + results */}
                            <div style={{padding:"9px 18px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:8,borderBottom:"1px solid #0d1828"}}>
                              <div style={{flex:1}}>
                                {analysis.status==="idle"&&<div style={{fontSize:9,color:"#2d4060",fontFamily:"monospace"}}>Tap Analyze — real 2026 stats, umpire, odds, HR scores</div>}
                                {analysis.status==="loading"&&(
                                  <div>
                                    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                                      <div style={{width:8,height:8,borderRadius:"50%",background:"#f5a623",flexShrink:0}}/>
                                      <span style={{fontSize:9,color:"#f5a623",fontFamily:"monospace",fontWeight:700}}>Analyzing {side.batting} vs {side.pitcher}...</span>
                                    </div>
                                    {["Real 2026 pitcher stats + form","Umpire zone rating","Batter Statcast EV / Barrel%","HR prop odds (DraftKings/FanDuel)","Scoring 9 batters across 9 factors"].map((s,si2)=>(
                                      <div key={si2} style={{display:"flex",alignItems:"center",gap:6,marginBottom:3}}>
                                        <div style={{width:5,height:5,borderRadius:"50%",background:"#1a3a2a",flexShrink:0}}/>
                                        <span style={{fontSize:8,color:"#2d4060",fontFamily:"monospace"}}>{s}</span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                                {analyzed&&(
                                  <div>
                                    <div style={{fontSize:9,color:"#81c784",fontFamily:"monospace",fontWeight:700,marginBottom:3}}>✓ AI Analysis Complete</div>
                                    {analysis.umpire&&<div style={{fontSize:9,color:"#ce93d8",fontFamily:"monospace",marginBottom:2}}>👤 {analysis.umpire}</div>}
                                    {analysis.pitcherTrend&&<div style={{fontSize:9,color:"#81c784",fontFamily:"monospace",marginBottom:2}}>📈 {analysis.pitcherTrend}</div>}
                                    {analysis.weather&&<div style={{fontSize:9,color:"#8ab8c8",fontFamily:"monospace",marginBottom:2}}>🌤 {analysis.weather}</div>}
                                    {analysis.summary&&<div style={{fontSize:9,color:"#8ab0c8",lineHeight:1.5,marginBottom:2}}>{analysis.summary}</div>}
                                    {analysis.bestBet&&<div style={{fontSize:10,color:"#f5a623",fontFamily:"monospace",fontWeight:700,padding:"4px 8px",background:"rgba(245,166,35,0.08)",borderRadius:5,marginTop:4}}>🎯 BEST BET: {analysis.bestBet}</div>}
                                  </div>
                                )}
                                {analysis.status==="error"&&<div style={{fontSize:9,color:"#ef5350",fontFamily:"monospace"}}>{analysis.summary}</div>}
                              </div>
                              <button onClick={e=>{e.stopPropagation();analyzeMatchup(side);}} disabled={aLoad}
                                style={{padding:"8px 14px",borderRadius:7,border:"1px solid",borderColor:analyzed?"#1a3a1a":aLoad?"#101c2c":"#f5a623",background:analyzed?"rgba(129,199,132,0.08)":aLoad?"#060d18":"rgba(245,166,35,0.10)",color:analyzed?"#81c784":aLoad?"#2d4060":"#f5a623",cursor:aLoad?"not-allowed":"pointer",fontSize:analyzed?9:10,fontFamily:"monospace",fontWeight:700,flexShrink:0,lineHeight:1.4,textAlign:"center"}}>
                                {aLoad?"⚙":"🔍"}<br/>{aLoad?"Analyzing...":analyzed?"Re-analyze":"Analyze"}
                              </button>
                            </div>

                            {/* Column headers */}
                            <div style={{display:"grid",gridTemplateColumns:"18px 22px 1fr 38px 64px 40px 30px",gap:3,padding:"5px 18px 4px",borderBottom:"1px solid #101c2c",background:T.bgHeader}}>
                              {["","#","BATTER","HRs","SCORE","HR%",""].map((h,hi)=>(
                                <span key={hi} style={{fontSize:7,color:analyzed?"#2d5040":"#1e3040",fontFamily:"monospace",textAlign:hi>=3?"right":hi===6?"center":"left"}}>{h}{hi===4&&analyzed?" ✓":""}</span>
                              ))}
                            </div>

                            {/* Level 3: Players */}
                            <div style={{padding:"4px 10px 8px"}}>
                              {displayPlayers.map((p,pi)=>{
                                const effScore=analyzed?p.score:getEffectiveScore(p,side.batting,p.score);
                                const effHrPct=toHrPct(effScore);
                                const col=sCol(effScore);
                                const eKey=`${p.name}-${side.gk}-${side.batting}`;
                                const isExp=openPlayers.has(eKey);
                                const pl=p.platoon==="ADV"?"✅":p.platoon==="DIS"?"⚠️":"⚖️";
                                const hasBoost=!analyzed&&effScore!==p.score;
                                const slot=getLineupSlot(side.batting,p.name);
                                const slotColor=slot&&slot<=4?"#f5a623":slot&&slot<=6?"#4fc3f7":"#5a7090";
                                const slotBg=slot&&slot<=4?"rgba(245,166,35,0.12)":slot&&slot<=6?"rgba(79,195,247,0.10)":"rgba(90,112,144,0.10)";
                                const lhr=getStat(p.name,"hr",null);
                                const lavg=getStat(p.name,"avg",null);
                                const lslg=getStat(p.name,"slg",null);
                                const lk=getStat(p.name,"k",null);
                                const lab=getStat(p.name,"ab",null);
                                const isLive=lhr!=null;
                                return(
                                  <div key={pi}>
                                    <button onClick={()=>togglePlayer(eKey)}
                                      style={{width:"100%",background:isExp?T.bgCard:pi===0?"rgba(245,166,35,0.04)":"transparent",border:"none",cursor:"pointer",padding:"6px 4px",borderRadius:5,marginBottom:1}}>
                                      <div style={{display:"grid",gridTemplateColumns:"18px 22px 1fr 38px 64px 40px 30px",gap:3,alignItems:"center"}}>
                                        <span style={{fontSize:9,color:isExp?"#81c784":"#2d4060",display:"inline-block",transform:isExp?"rotate(90deg)":"rotate(0deg)",transition:"transform 0.2s"}}>▶</span>
                                        <span style={{fontSize:pi<3?12:10,color:pi===0?"#f5a623":pi===1?"#c0c8d8":pi===2?"#9a8060":col,fontWeight:700,fontFamily:"monospace"}}>{pi===0?"①":pi===1?"②":pi===2?"③":pi+1}</span>
                                        <div style={{minWidth:0}}>
                                          <div style={{display:"flex",alignItems:"center",gap:4}}>
                                            <div style={{fontSize:11,color:pi<3?col:"#b0c8e0",fontWeight:pi<3?600:400,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.name}</div>
                                            {p.aiScored&&<span style={{fontSize:7,color:"#81c784",fontFamily:"monospace",background:"rgba(129,199,132,0.12)",padding:"1px 4px",borderRadius:3,flexShrink:0}}>AI</span>}
                                            {p.missingStats&&<span style={{fontSize:7,color:"#5a4020",fontFamily:"monospace",background:"rgba(90,64,32,0.20)",padding:"1px 4px",borderRadius:3,flexShrink:0}}>no Statcast</span>}
                                            {lineupLoaded&&slot&&<span style={{fontSize:7,color:slotColor,fontFamily:"monospace",background:slotBg,padding:"1px 5px",borderRadius:3,flexShrink:0}}>#{slot}</span>}
                                            {lineupLoaded&&!slot&&<span style={{fontSize:7,color:"#3a1010",fontFamily:"monospace",background:"rgba(239,83,80,0.12)",padding:"1px 4px",borderRadius:3,flexShrink:0}}>?</span>}
                                          </div>
                                          <div style={{fontSize:7,color:"#2d4060",fontFamily:"monospace"}}>{p.pos} · {p.hand}HH · {pl}</div>
                                        </div>
                                        <div style={{textAlign:"right"}}>
                                          {!statsLoaded
                                            ?<div><span style={{fontSize:10,color:"#2d4060",fontFamily:"monospace"}}>⟳</span><div style={{fontSize:6,color:"#1e3040",fontFamily:"monospace"}}>loading</div></div>
                                            :lhr==null
                                              ?<div><span style={{fontSize:11,color:"#2d4060",fontFamily:"monospace"}}>—</span><div style={{fontSize:6,color:"#1e3040",fontFamily:"monospace"}}>no data</div></div>
                                              :<div><span style={{fontSize:12,color:hrCol(lhr),fontFamily:"monospace",fontWeight:700}}>{lhr}</span><div style={{fontSize:6,color:"#f5a623",fontFamily:"monospace"}}>✓ live</div></div>
                                          }
                                        </div>
                                        <div style={{textAlign:"right"}}>
                                          <div style={{height:3,background:"#0d1828",borderRadius:2,overflow:"hidden",marginBottom:2}}><div style={{width:`${effScore}%`,height:"100%",background:col,borderRadius:2}}/></div>
                                          <span style={{fontSize:10,color:col,fontFamily:"monospace",fontWeight:700}}>{effScore}/100</span>
                                          {hasBoost&&<div style={{fontSize:6,color:effScore>p.score?"#81c784":"#ef5350",fontFamily:"monospace"}}>{effScore>p.score?"↑":"↓"}{Math.abs(effScore-p.score)}</div>}
                                        </div>
                                        <div style={{textAlign:"right"}}><span style={{fontSize:12,color:col,fontFamily:"monospace",fontWeight:700}}>{analyzed?p.hrPct:effHrPct}%</span></div>
                                        <div style={{textAlign:"center",fontSize:13}}>{tier(effScore)}</div>
                                      </div>
                                    </button>
                                    {isExp&&(
                                      <div style={{margin:"2px 0 6px",background:T.bgDeep,borderRadius:8,border:`1px solid ${T.borderAcc}`,borderLeft:"3px solid "+col,overflow:"hidden"}}>
                                        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"8px 12px",borderBottom:"1px solid #101c2c"}}>
                                          <div style={{flex:1}}>
                                            <div style={{display:"flex",alignItems:"center",gap:7,flexWrap:"wrap"}}>
                                              <span style={{fontSize:12,color:col,fontWeight:700}}>{p.name}</span>
                                              {p.aiScored&&<span style={{fontSize:8,color:"#81c784",fontFamily:"monospace",background:"rgba(129,199,132,0.12)",padding:"2px 6px",borderRadius:4}}>✓ AI Scored</span>}
                                              <span style={{fontSize:8,color:"#2d4060",fontFamily:"monospace"}}>{p.pos} · {p.hand}HH</span>
                                              {lineupLoaded&&slot&&(
                                                <span style={{fontSize:9,fontFamily:"monospace",padding:"2px 8px",borderRadius:4,fontWeight:700,background:slotBg,color:slotColor}}>
                                                  #{slot} {slot===1?"Leadoff":slot<=4?"Heart of order":slot<=6?"Mid lineup":"Lower order"}
                                                </span>
                                              )}
                                              {lineupLoaded&&!slot&&<span style={{fontSize:9,fontFamily:"monospace",padding:"2px 8px",borderRadius:4,background:"rgba(239,83,80,0.12)",color:"#ef5350"}}>⚠ Not confirmed</span>}
                                              <span style={{fontSize:8,color:p.la>=25&&p.la<=35?"#f5a623":"#5a7090",fontFamily:"monospace"}}>LA {p.la>=25&&p.la<=35?"✓ HR zone":"⚠"}</span>
                                            </div>
                                          </div>
                                          <button onClick={e=>{e.stopPropagation();togglePlayer(eKey);}} style={{background:"transparent",border:"none",color:"#2d4060",cursor:"pointer",fontSize:12,padding:"2px 6px"}}>✕</button>
                                        </div>
                                        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:1,background:T.bgInner}}>
                                          {[
                                            {l:"Exit Velocity",v:`${p.ev} mph`,c:p.ev>=95?"#f5a623":p.ev>=91?"#4fc3f7":"#8a9bb8",note:p.ev>=95?"Elite":p.ev>=91?"Solid":"Below avg"},
                                            {l:"Launch Angle", v:`${p.la}°`,   c:p.la>=25&&p.la<=35?"#f5a623":p.la>=20?"#4fc3f7":"#8a9bb8",note:p.la>=25&&p.la<=35?"HR zone":p.la>=20?"Borderline":"Too flat"},
                                            {l:"Barrel Rate",  v:`${p.barrel}%`,c:p.barrel>=15?"#f5a623":p.barrel>=10?"#4fc3f7":"#8a9bb8",note:p.barrel>=15?"Elite":p.barrel>=10?"Good":"Low"},
                                            {l:"HR / FB Rate", v:`${p.hrfb}%`, c:p.hrfb>=20?"#f5a623":p.hrfb>=14?"#4fc3f7":"#8a9bb8",note:p.hrfb>=20?"Elite":p.hrfb>=14?"Solid":"Below avg"},
                                            {l:"Hard Hit %",   v:`${p.hh}%`,   c:p.hh>=50?"#f5a623":p.hh>=42?"#4fc3f7":"#8a9bb8",note:p.hh>=50?"Elite":p.hh>=42?"Good":"Avg"},
                                            {l:"Iso Power",    v:"."+Math.round(p.iso*1000),c:p.iso>=.28?"#f5a623":p.iso>=.22?"#4fc3f7":"#8a9bb8",note:p.iso>=.28?"Elite":p.iso>=.22?"Solid":"Moderate"},
                                          ].map(({l,v,c,note})=>(
                                            <div key={l} style={{padding:"9px 10px",background:"#070f1a",textAlign:"center"}}>
                                              <div style={{fontSize:7,color:"#2d4060",fontFamily:"monospace",marginBottom:3,textTransform:"uppercase",letterSpacing:.5}}>{l}</div>
                                              <div style={{fontSize:14,color:c,fontWeight:800,fontFamily:"monospace",lineHeight:1}}>{v}</div>
                                              <div style={{fontSize:7,color:c+"aa",fontFamily:"monospace",marginTop:3}}>{note}</div>
                                            </div>
                                          ))}
                                        </div>
                                        {p.aiScored&&p.topFactor&&(
                                          <div style={{padding:"8px 12px",borderTop:"1px solid #101c2c"}}>
                                            <div style={{fontSize:8,color:"#3a7040",fontFamily:"monospace",marginBottom:2,textTransform:"uppercase"}}>✅ AI Edge</div>
                                            <div style={{fontSize:11,color:"#b8d8b8",lineHeight:1.5}}>{p.topFactor}</div>
                                          </div>
                                        )}
                                        {p.aiScored&&p.redFlag&&(
                                          <div style={{padding:"8px 12px",borderTop:"1px solid #101c2c"}}>
                                            <div style={{fontSize:8,color:"#703a3a",fontFamily:"monospace",marginBottom:2,textTransform:"uppercase"}}>⚠️ Red Flag</div>
                                            <div style={{fontSize:11,color:"#d8b8b8",lineHeight:1.5}}>{p.redFlag}</div>
                                          </div>
                                        )}
                                        <div style={{padding:"8px 12px",borderTop:"1px solid #101c2c",background:isLive?"rgba(245,166,35,0.04)":"transparent"}}>
                                          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:isLive?6:0}}>
                                            <div style={{fontSize:8,color:isLive?"#f5a623":!statsLoaded?"#2d5070":"#3a1010",fontFamily:"monospace",minWidth:70,fontWeight:700}}>
                                              {!statsLoaded?"⟳ Loading...":isLive?"✓ 2026 LIVE":"⚠ Not found"}
                                            </div>
                                            {isLive&&(
                                              <div style={{display:"flex",alignItems:"center",gap:8,flex:1}}>
                                                <div style={{flex:1,height:4,background:"#0d1828",borderRadius:2,overflow:"hidden"}}>
                                                  <div style={{width:`${Math.min(100,(lhr/20)*100)}%`,height:"100%",background:hrCol(lhr),borderRadius:2}}/>
                                                </div>
                                                <span style={{fontSize:15,color:hrCol(lhr),fontFamily:"monospace",fontWeight:800,minWidth:24,textAlign:"right"}}>{lhr}</span>
                                              </div>
                                            )}
                                            {statsLoaded&&!isLive&&<span style={{fontSize:11,color:"#2d4060",fontFamily:"monospace"}}>— not matched in MLB API</span>}
                                          </div>
                                          {isLive&&(
                                            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                                              {lavg!=null&&<span style={{fontSize:9,fontFamily:"monospace",color:"#4fc3f7"}}>AVG {lavg}</span>}
                                              {lslg!=null&&<span style={{fontSize:9,fontFamily:"monospace",color:"#81c784"}}>SLG {lslg}</span>}
                                              {lk!=null&&lab!=null&&lab>0&&<span style={{fontSize:9,fontFamily:"monospace",color:"#8a9bb8"}}>K% {(lk/lab*100).toFixed(0)}%</span>}
                                            </div>
                                          )}
                                        </div>
                                        {/* ── PITCH MIX PANEL ── */}
                                        {PITCHERS[side.pitcher]?.mix&&(()=>{
                                          const pitData=PITCHERS[side.pitcher];
                                          const pbvp=BATTER_VS_PITCH[p.name]||null;
                                          const ranked=pitData.mix
                                            .filter(pm=>pm?.name)
                                            .map(pm=>{
                                              const cat=pitchCategory(pm.name);
                                              const bs=pbvp?.[cat]||{hrRate:0.10,slg:0.420,whiff:22};
                                              return{...pm,cat,bs,ms:(pm.pct/100)*bs.hrRate*100};
                                            })
                                            .sort((a,b)=>b.ms-a.ms);
                                          if(!ranked.length) return null;
                                          const top=ranked[0];
                                          const catLabel={FA:"Fastballs",BR:"Breaking Balls",OS:"Offspeed"}[top.cat]||"";
                                          return(
                                            <div style={{borderTop:"1px solid #101c2c",padding:"9px 12px",background:"#060e1a"}}>
                                              <div style={{fontSize:8,color:"#2d4060",fontFamily:"monospace",letterSpacing:1.2,textTransform:"uppercase",marginBottom:7}}>Pitch Mix · Best Pitch to Hit</div>
                                              <div style={{marginBottom:8}}>
                                                {pitData.mix.filter(pm=>pm?.name).map((pm,mi)=>{
                                                  const cat=pitchCategory(pm.name);
                                                  const bs=pbvp?.[cat]||{hrRate:0.10,slg:0.420,whiff:22};
                                                  const isHot=pm.name===top.name;
                                                  return(
                                                    <div key={mi} style={{marginBottom:5}}>
                                                      <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:2}}>
                                                        <span style={{fontSize:9,fontFamily:"monospace",color:isHot?"#f5a623":"#8ab0c8",fontWeight:isHot?700:400,minWidth:72}}>{pm.name}</span>
                                                        <span style={{fontSize:8,fontFamily:"monospace",color:"#2d4060",minWidth:30}}>{pm.pct}%</span>
                                                        <span style={{fontSize:8,fontFamily:"monospace",color:"#1e3040",minWidth:36}}>{pm.velo}mph</span>
                                                        <span style={{fontSize:8,fontFamily:"monospace",color:isHot?"#f5a623":"#2d4060",marginLeft:"auto"}}>
                                                          {isHot?"🎯 ":""}SLG {bs.slg.toFixed(3)} · {bs.hrRate.toFixed(2)}/100
                                                        </span>
                                                      </div>
                                                      <div style={{height:4,background:"#0d1828",borderRadius:2,overflow:"hidden"}}>
                                                        <div style={{width:pm.pct+"%",height:"100%",background:isHot?"#f5a623":pm.pct>30?"#4fc3f7":"#2d4060",borderRadius:2}}/>
                                                      </div>
                                                    </div>
                                                  );
                                                })}
                                              </div>
                                              <div style={{padding:"6px 10px",borderRadius:6,background:"rgba(245,166,35,0.08)",border:"1px solid rgba(245,166,35,0.2)"}}>
                                                <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                                                  <span style={{fontSize:9,color:"#f5a623",fontFamily:"monospace",fontWeight:700}}>🎯 Best pitch to hit:</span>
                                                  <span style={{fontSize:10,color:"#ddeeff",fontFamily:"monospace",fontWeight:700}}>{top.name} ({top.pct}% usage)</span>
                                                  <span style={{fontSize:8,color:"#8ab0c8",fontFamily:"monospace"}}>{pbvp?"SLG ."+Math.round((pbvp[top.cat]?.slg||0.420)*1000)+" vs "+catLabel:"league avg"}</span>
                                                </div>
                                              </div>
                                            </div>
                                          );
                                        })()}
                                        <div style={{padding:"7px 12px",borderTop:"1px solid #101c2c",background:"#06101a"}}>
                                          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                                            <span style={{fontSize:9,fontFamily:"monospace",padding:"2px 7px",borderRadius:4,background:p.hand===side.pitHand?"rgba(239,83,80,0.12)":p.hand==="S"?"rgba(138,155,184,0.12)":"rgba(129,199,132,0.12)",color:p.hand===side.pitHand?"#ef5350":p.hand==="S"?"#8a9bb8":"#81c784"}}>
                                              {p.hand==="S"?"⚖️ Switch":p.hand!==side.pitHand?"✅ Platoon ADV":"⚠️ Same-hand DIS"}
                                            </span>
                                            <span style={{fontSize:9,fontFamily:"monospace",padding:"2px 7px",borderRadius:4,background:"rgba(79,195,247,0.10)",color:"#4fc3f7"}}>Score {effScore}/100</span>
                                            <span style={{fontSize:9,fontFamily:"monospace",padding:"2px 7px",borderRadius:4,background:"rgba(245,166,35,0.10)",color:col}}>{analyzed?p.hrPct:effHrPct}% per game</span>
                                            <span style={{fontSize:9,fontFamily:"monospace",padding:"2px 7px",borderRadius:4,background:side.pf>=1.05?"rgba(245,166,35,0.10)":side.pf<=0.93?"rgba(79,195,247,0.08)":"rgba(138,155,184,0.08)",color:pfCol(side.pf)}}>
                                              {side.pf>=1.10?"🔥":side.pf<=0.93?"🧊":"⚖️"} PF {side.pf}
                                            </span>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}

        <div style={{textAlign:"center",marginTop:10,fontSize:8,color:"#0f1a28",fontFamily:"monospace"}}>
          9-Factor Statcast Model · MLB Stats API · For entertainment only
        </div>
      </div>
      <style>{`*{box-sizing:border-box;}body{background:${T.bg}}`}</style>
    </div>
  );
}
